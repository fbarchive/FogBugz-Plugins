
var CategoryEdit = {};

	CategoryEdit.refreshWithin = function(el) {
		var elRadioSelect = $("#idUploadIconFalse", el)[0];
		var elRadioUpload = $("#idUploadIconTrue", el)[0];

		var jrgInput = $("input[type='radio'][name$='nIconType']", el);
		var jrgLabel = jrgInput.add(elRadioSelect).add(elRadioUpload).map(function() { return $("label[for='" + this.id + "']")[0]; });	

		var refreshHighlight = function() {
			var sSelected = elRadioSelect.checked ? "catIconSelected" : "catIconUnselected";
			jrgLabel.each(function() {
					var elInput = elById(this.htmlFor);
					this.className = (elInput && elInput.checked ? sSelected : "catIconUnselected");
				});

		}

		jrgInput.css("display", "none");
		jrgLabel.click(function() { 
				var elInput = elById(this.htmlFor);
				if (elInput) elInput.checked = true;
				elRadioSelect.checked = true;
				refreshHighlight(); 
			});
		$("#idFileUpload", el).click(function() { elRadioUpload.checked = true; refreshHighlight(); });
		$(elRadioSelect).add(elRadioUpload).click(function() { refreshHighlight(); });

		refreshHighlight();
	}

var WorkflowEdit = {};

	WorkflowEdit.showProjects = function(ixWorkflow) {
		$("#projects_" + ixWorkflow + "_hidden").css("display", "none");
		$("#projects_" + ixWorkflow + "_shown").css("display", "");
	}

	WorkflowEdit.hideProjects = function(ixWorkflow) {
		$("#projects_" + ixWorkflow + "_hidden").css("display", "");
		$("#projects_" + ixWorkflow + "_shown").css("display", "none");
	}
