﻿function devmentalInputTextField_OnFocus(elmtId, defaultText) {
    var inputField = document.getElementById(elmtId);

    if (inputField.value == defaultText) {
        inputField.value = ""
        inputField.style.color = "black";
    }
}

function devmentalInputTextField_OnBlur(elmtId, defaultText) {
    var inputField = document.getElementById(elmtId);

    if (inputField.value != defaultText && inputField.value.length == 0) {
        inputField.value = defaultText;
        inputField.style.color = "Gray";
    }
}

function updateLicenseStatus(pluginUrl, pluginPrefix, action, actionToken, ixPerson, newStatus) {
    $.ajax({
        'async': false,
        'global': false,
        'url': pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix + 
               'ixPerson=' + ixPerson + '&' + pluginPrefix + 'newStatus=' + newStatus + '&' +
               pluginPrefix + 'actionToken=' + actionToken,
        'success': function (data) {
            if (data.length > 0) {
                window.location = data;
            }
        }
    });
}

function installNewLicense(pluginUrl, pluginPrefix, action, actionToken) {
    var licenseKey = $('#newLicenseKey').val();
    $.ajax({
        'async': false,
        'global': false,
        'url': pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix +
               'licenseKey=' + licenseKey + '&' + pluginPrefix + 'actionToken=' + actionToken,
        'success': function (data) {
            if (data.length > 0) {
                window.location = data;
            }
        }
    });
}

function gotoNewWikiPage(pluginUrl, pluginPrefix, action, actionToken, ixBug) {
    $.ajax({
        'async': false,
        'global': false,
        'url': pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix +
               'actionToken=' + actionToken + '&' + pluginPrefix + 'ixBug=' + ixBug,
        'success': function (data) {
            if (data.length > 0) {
                window.location = data;
            }
        }
    });
}

function detachWikiPage(pluginUrl, pluginPrefix, action, actionToken, wikiPageId, ixBug)
{
    $.ajax({
        'async': false,
        'global': false,
        'url': pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix +
               'actionToken=' + actionToken + '&' + pluginPrefix + 'ixWikipage=' + wikiPageId +
               '&' + pluginPrefix + 'ixBug=' + ixBug,
        'success': function(data) {
            if (data.length > 0) {
                window.location = data;
            }
        }
    });
}

function attachCaseToWikiPage(pluginUrl, pluginPrefix, action, actionToken, ixBug)
{
    var wikiPageId = $('#wikiPageId').val();
    var url = pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix +
               'actionToken=' + actionToken + '&' + pluginPrefix + 'ixWikipage=' + wikiPageId +
               '&' + pluginPrefix + 'ixBug=' + ixBug;
    jQuery.get(url, function(data) {
        if (data.length > 0) {
            window.location = data;
        }
        else
        {
            var errMsg = document.getElementById("errorMsgLbl");
            errMsg.style.color = "red";
            errMsg.style.display = "block";
        }
    });
}

function wikiPageIdTextField_OnKeyPress(elmt, event, pluginUrl, pluginPrefix, action, actionToken, ixBug)
{
    if (getKeyCode(event) == 13) {
        attachCaseToWikiPage(pluginUrl, pluginPrefix, action, actionToken, ixBug);
        cancel(event);
        return false;
    }
}

function gotoNewCase(pluginUrl, pluginPrefix, action, actionToken, ixWikiPage) {
    $.ajax({
        'async': false,
        'global': false,
        'url': pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix +
               'ixWikipage=' + ixWikiPage + '&' + pluginPrefix + 'actionToken=' + actionToken,
        'success': function (data) {
            if (data.length > 0) {
                window.location = data;
            }
        }
    });
}

function assignWiki(pluginUrl, pluginPrefix, action, actionToken, ixProject, ixWiki) 
{
    $.ajax({
        'async': false,
        'global': false,
        'url': pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix +
              'actionToken=' + actionToken + '&' + pluginPrefix + 'ixProject=' + ixProject +
              '&' + pluginPrefix + 'ixWiki=' + ixWiki,
        'success': function (data) {
            if (data.length > 0) {
                window.location = data;
            }
        }
    });
}

function assignWikiPage(pluginUrl, pluginPrefix, action, actionToken, ixProject, ixWikiPage) {
    $.ajax({
        'async': false,
        'global': false,
        'url': pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix +
              'actionToken=' + actionToken + '&' + pluginPrefix + 'ixProject=' + ixProject +
              '&' + pluginPrefix + 'ixWikiPage=' + ixWikiPage,
        'success': function (data) {
            if (data.length > 0) {
                window.location = data;
            }
        }
    });
}

function detachCase(pluginUrl, pluginPrefix, action, actionToken, ixBug, ixWikiPage)
{
    $.ajax({
        'async': false,
        'global': false,
        'url': pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix +
              'actionToken=' + actionToken + '&' + pluginPrefix + 'ixWikipage=' + ixWikiPage +
              '&' + pluginPrefix + 'ixBug=' + ixBug,
        'success': function(data) {
            if (data.length > 0) {
                window.location = data;
            }
        }
    });
}

function attachWikipageToCase(pluginUrl, pluginPrefix, action, actionToken, ixWikiPage)
{
    var caseId = $('#caseId').val();
    var url = pluginUrl + '&' + pluginPrefix + 'action=' + action + '&' + pluginPrefix +
              'actionToken=' + actionToken + '&' + pluginPrefix + 'ixWikipage=' + ixWikiPage +
              '&' + pluginPrefix + 'ixBug=' + caseId;
    jQuery.get(url, function(data) {
        if (data.length > 0) {
            window.location = data;
        }
        else
        {
            var errMsg = document.getElementById("errorMsgLbl");
            errMsg.style.color = "red";
            errMsg.style.display = "block";
        }
    });
}
