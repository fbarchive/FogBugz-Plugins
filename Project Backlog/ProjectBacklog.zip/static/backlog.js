var ProjectBacklog = new function(){
	var fLoaded = false;
	var oSelf = this;
	var elClickedRow = null;

	function toInt(s) {
	    return parseInt(s, 10);
	}
	
	this.disable = function(){
		this.doGridPopup = function(){return true;};
		this.doCasePopup = function(){return true;};
	};
	
	this.enable = function(){
		this.doGridPopup = this.doGridPopupFn;
		this.doCasePopup = this.doCasePopupFn;
	};
	
	this.setBacklogValue = function (ixBug, ixProject, iBacklogOld, iBacklogNew, fGridView)
	{
		oSelf.disable();
		oSelf.refreshBacklogOrdering(ixBug, ixProject, iBacklogOld, iBacklogNew, fGridView);
		oSelf.enable();
		
		// send the ajax request to update things on the server
		var sUrl = oSelf.PluginRawPageUrl + "&" +
			oSelf.PluginPrefix + "pre=" + oSelf.PreSetBacklog + "&"+
			oSelf.PluginPrefix + "ix=" + ixBug + "&" +
			oSelf.BugsToEditName + "=|" + ixBug + "|&" +
			oSelf.PluginPrefix + "iBacklogNew=" + iBacklogNew;
		
		jQuery.get(sUrl);
	};
	
	this.refreshBacklogOrdering = function (ixBug, ixProject, iBacklogOld, iBacklogNew, fGridView)
	{
		if(oSelf.rgBacklogs[ixProject] === undefined)
			oSelf.rgBacklogs[ixProject] = [];
		
		iBacklogOld = toInt(iBacklogOld); if(isNaN(iBacklogOld) || iBacklogOld < 0) iBacklogOld = 0;
		iBacklogNew = toInt(iBacklogNew); if(isNaN(iBacklogNew) || iBacklogNew < 0) iBacklogNew = 0;
		iBacklogNew = Math.min(iBacklogNew, iBacklogOld > 0 ? oSelf.rgBacklogs[ixProject].length : oSelf.rgBacklogs[ixProject].length + 1);
		
		if(fGridView === false)
		{
			YFTManager.showYellow('BacklogFade', $('#dottedBacklog').text(iBacklogNew === 0 ? FB_NONE : iBacklogNew)[0]);
			
			// update our internal backlog representation
			updateInternalBacklog(ixBug, ixProject, iBacklogOld, iBacklogNew);
			
			TabManager.fForceFullPageRefresh = true;
		}
		else
		{
			var target = findTarget(ixBug, ixProject, iBacklogOld, iBacklogNew);
			
			// update our internal backlog representation
			updateInternalBacklog(ixBug, ixProject, iBacklogOld, iBacklogNew);
			
			// if we found a target, move the clicked row into its new position
			if(target.uidTarget > -1 && target.uidTarget !== oSelf.elClickedRow.uid)
			{
				// move the clicked row to the appropriate position in relation to the target row
				var elTargetRow = $('#bugGrid tr').filter(function() {
					return this.uid === target.uidTarget;
				})[0];
				
				// grab subcases of the row we're moving
				var rgSubcases = GridControl.getDescendentRows(oSelf.elClickedRow.uid);
				
				// move the root row to it's proper position
				if(target.fAbove)
					$(oSelf.elClickedRow).insertBefore(elTargetRow);
				else
					$(oSelf.elClickedRow).insertAfter(elTargetRow);
				
				var ixRemove = GridControl.rowFromUID(oSelf.elClickedRow.uid);
				var ixInsert = GridControl.rowFromUID(elTargetRow.uid);
				
				GridControl.removeGridDataRow(ixRemove);
				oSelf.elClickedRow.id = "row_" + ixInsert;
				GridControl.insertGridDataRow(ixInsert, oSelf.elClickedRow, true);
				
				// make the subcases follow suit
				if(rgSubcases.length > 0)
				{
					elTargetRow = oSelf.elClickedRow;
					for (var ix = 0; ix < rgSubcases.length; ix++)
					{
						$(rgSubcases[ix]).insertAfter(elTargetRow);
						
						// a) if we're visually moving UP in the grid view, each subcase's
						// ixRemove & ixInsert will increase by one b/c we're injecting
						// an additional row "above" us on each iteration
						//
						// b) if we're visually moving DOWN in the grid view, each subcase's
						// ixRemove & ixInsert will be the same b/c we're removing a row
						// from "above" us on each iteration
						if(ixInsert < ixRemove)
						{
							ixRemove++;
							ixInsert++;
						}
						
						GridControl.removeGridDataRow(ixRemove);
						rgSubcases[ix].id = "row_" + ixInsert;
						GridControl.insertGridDataRow(ixInsert, rgSubcases[ix], true);
						
						elTargetRow = rgSubcases[ix];
					}
				}
				
				GridControl.zebraStripe();
			}
			
			// perform any necessary DOM changes to the clicked row and update
			// values of all the backlogged cases currently visible to reflect changes
			updateBacklogDOM(oSelf.elClickedRow, ixProject, iBacklogOld, iBacklogNew);
		}
	};
	
	function findTarget(ixBug, ixProject, iBacklogOld, iBacklogNew)
	{
		var uidTarget = -1;
		var fAbove = (oSelf.fDescending === 1 && iBacklogNew > iBacklogOld) || (oSelf.fDescending === 0 && iBacklogNew < iBacklogOld);
		
		// if we're sorted AND either *not* a subcase OR in flat
		// view, find the target location for the modified row
		if(oSelf.fDescending > -1 && (g_fFlatView === true || GridControl.getDepth(oSelf.elClickedRow) === 0))
		{
			var elNext = oSelf.elClickedRow;
			var iNext = iBacklogOld;
			
			var elCurr;
			var iCurr;
			var fContinue;
			
			if(iBacklogNew === 0)
			{
				fAbove = false;
				
				// skip over any rows between current position and the "bottom" of the list of backlogged cases
				do
				{
					elCurr = elNext;
					elNext = elNext.nextSibling;
				}
				while(elNext && elNext.nodeName === "TR" && (GridControl.getDepth(elNext) > 0 || !($('.projectBacklogGridContainer', elNext).hasClass('fFakeIBacklog'))));
			}
			else
			{
				if(iBacklogOld === 0)
				{
					fAbove = true; // inserting into the backlog is always "above" our current position
					
					// skip over blank rows between current position and the "bottom" of the list of backlogged cases
					do
					{
						elCurr = elNext;
						elNext = elNext.previousSibling;
					}
					while(elNext && elNext.nodeName === "TR" && (GridControl.getDepth(elNext) > 0 || $('.projectBacklogGridContainer', elNext).hasClass('fFakeIBacklog')));
					
					// back up one so we don't mess up the logic of the following do-while loop
					elNext = elCurr;
				}
				
				do
				{
					elCurr = elNext;
					elNext = fAbove ? elNext.previousSibling : elNext.nextSibling;
					
					// skip over subcases!
					while(elNext && elNext.nodeName === "TR" && GridControl.getDepth(elNext) > 0)
						elNext = fAbove ? elNext.previousSibling : elNext.nextSibling;
					
					iCurr = iNext;
					
					iNext = toInt($(".projectBacklogBacklog", elNext).text());
					if(isNaN(iNext)) iNext = 0;
					
					if(iBacklogOld === 0)
					{
						// continue logic when adding to the backlog
						fContinue = oSelf.fDescending === 0 ?
									iNext >= iBacklogNew
									:
									iNext < iBacklogNew && iNext > 0;
					}
					else
					{
						// continue logic when moving within the backlog
						fContinue = iBacklogNew < iBacklogOld ?
									iCurr > iBacklogNew && iNext >= iBacklogNew
									:
									iCurr < iBacklogNew && iNext <= iBacklogNew && iNext > 0;
					}
				}while(elNext && elNext.nodeName === "TR" && fContinue);
			}
			
			// make sure we skip over any subcases of the target row
			if(
				(!fAbove && GridControl.hasDescendentRows(elCurr.uid))
				||
				(fAbove && elNext && elNext.uid && GridControl.hasDescendentRows(elNext.uid))
			)
			{
				elNext = fAbove ? elNext.nextSibling : elCurr.nextSibling;
				
				while(elNext && elNext.nodeName === "TR" && GridControl.getDepth(elNext) > 0)
				{
					elCurr = elNext;
					elNext = elNext.nextSibling;
				}
				
				if(fAbove) elCurr = elNext; // b/c we're going to do an "insert before"
			}
			
			uidTarget = elCurr.uid;
		}
		
		return new target(uidTarget, fAbove);
	}
	
	function target(uidTarget, fAbove)
	{
		this.uidTarget = uidTarget;
		this.fAbove = fAbove;
	}
	
	function updateInternalBacklog(ixBug, ixProject, iBacklogOld, iBacklogNew)
	{
		// step 1: remove from old position
		if(iBacklogOld > 0) oSelf.rgBacklogs[ixProject].splice(iBacklogOld - 1, 1);
		// step 2: insert at new position
		if(iBacklogNew > 0) oSelf.rgBacklogs[ixProject].splice(iBacklogNew - 1, 0, ixBug);
	}
	
	function updateBacklogDOM(elClickedRow, ixProject, iBacklogOld, iBacklogNew)
	{
		var elBacklog = $('.projectBacklogGridContainer', elClickedRow);
		
		if(iBacklogOld === 0) // added to backlog
		{
			elBacklog.removeClass('fFakeIBacklog');
			$('span.projectBacklogBacklog', elBacklog).after('<span class="projectBacklogArrows" />');
		}
		
		if(iBacklogNew === 0) // removed from backlog
		{
			elBacklog.addClass('fFakeIBacklog');
			$('span.projectBacklogArrows', elBacklog).remove();
			$('span.projectBacklogBacklog', elBacklog).empty();
		}
		
		// update all the cases in this project's backlog to reflect their new positions
		$('.projectBacklogGridContainer[ixProject="' + ixProject + '"]:not(.fFakeIBacklog)').each(
			function() {
				var sUpLink = oSelf.BlankArrow;
				var sDnLink = oSelf.BlankArrow;
				
				var myIxBug = toInt($(this).attr("ixBug"));
				var newBacklog = oSelf.rgBacklogs[ixProject].firstMatchIndex(function(ix) {return ix === myIxBug;}) + 1;
				
				$('span.projectBacklogArrows', this).empty();
				
				// arrow links only make sense if we're sorted AND either in flat view OR *not* a subcase
				if(oSelf.fDescending > -1 && (g_fFlatView === true || GridControl.getDepth($(this).parents('tr:first')[0]) === 0))
				{
					sUpLink = buildArrowLink(oSelf.UpArrow, oSelf.fDescending === 1 ? oSelf.PreInc : oSelf.PreDec, myIxBug);
					sDnLink = buildArrowLink(oSelf.DnArrow, oSelf.fDescending === 1 ? oSelf.PreDec : oSelf.PreInc, myIxBug);
					
					if(newBacklog === 1)
					{
						if (oSelf.fDescending === 1)
							sDnLink = oSelf.BlankArrow;
						else
							sUpLink = oSelf.BlankArrow;
					}
					
					if(newBacklog === oSelf.rgBacklogs[ixProject].length)
					{
						if (oSelf.fDescending === 1)
							sUpLink = oSelf.BlankArrow;
						else
							sDnLink = oSelf.BlankArrow;
					}
				}
				
				$('span.projectBacklogArrows', this).html(sUpLink + sDnLink);
				$('span.projectBacklogBacklog', this).html(buildDottedLink(newBacklog, myIxBug));
			}
		);
	}
	
	function buildArrowLink(sContent, pre, sixBug)
	{
		return '<a href="' + oSelf.PluginPageUrl + '&' + oSelf.PluginPrefix + 'pre=' + pre + '&' + oSelf.PluginPrefix + 'ix=' + sixBug + '&' + oSelf.BugsToEditName + '=|' + sixBug + '|"' +
				' onclick="ProjectBacklog.nudgeBacklog(this, \'' + pre + '\'); return ProjectBacklog.cancelAndStopBubble(event);"' +
				' class="projectBacklogPageLink"' +
				'>' + sContent + '</a>';
	}
	
	function buildDottedLink(iBacklog, ixBug)
	{
		return '<a href="' + oSelf.BugEditUrl.replace('-1', ixBug) + '"' +
				' class="dotted"' + 
				' onclick="ProjectBacklog.doGridPopup(this, event); return ProjectBacklog.cancelAndStopBubble(event);"' +
				'>' + iBacklog + '</a>';
	}
	
	this.nudgeBacklog = function(elArrowLink, dir)
	{
		var elClickedTr = $(elArrowLink).parents('tr:first');
		oSelf.elClickedRow = elClickedTr[0];
		
		var backlogDiv = elClickedTr.find(".projectBacklogGridContainer");
		var ixBug = toInt(backlogDiv.attr("ixBug"));
		var ixProject = toInt(backlogDiv.attr("ixProject"));
		
		var iBacklogOld = toInt(backlogDiv.find(".projectBacklogBacklog").text());
		if(isNaN(iBacklogOld)) iBacklogOld = 0;
		
		var iBacklogNew = (dir === oSelf.PreInc ? iBacklogOld + 1 : iBacklogOld - 1);
		
		oSelf.setBacklogValue(ixBug, ixProject, iBacklogOld, iBacklogNew, true);
	}
	
	this.doCasePopupFn = function (el)
	{
		var iBacklog = isNaN(toInt($("#dottedBacklog").text())) ? "" : $("#dottedBacklog").text();
		var ixBug = toInt($(el).attr("ixBug"));
		var ixProject = toInt($(el).attr("ixProject"));
		var fAdding = (iBacklog.length === 0);
		
		return doRawPopup(el, iBacklog, ixBug, ixProject, fAdding, false);
	};
	
	this.doGridPopupFn = function (el, e)
	{
		var elClickedTr = $(el).parents('tr:first');
		oSelf.elClickedRow = elClickedTr[0];
		
		var backlogDiv = elClickedTr.find(".projectBacklogGridContainer");
		var ixBug = toInt(backlogDiv.attr("ixBug"));
		var ixProject = toInt(backlogDiv.attr("ixProject"));
		var iBacklog = backlogDiv.find(".projectBacklogBacklog").text();
		var fAdding = backlogDiv.hasClass('fFakeIBacklog');
		
		return doRawPopup(backlogDiv.parents('td:first')[0], iBacklog, ixBug, ixProject, fAdding, true);
	};
	
	this.cancelAndStopBubble = function(e)
	{
		if (!e) return false;
		e.cancelBubble = true;
		if (e.stopPropagation) e.stopPropagation();
		return false;
	};
	
	var cancel = '"ProjectBacklog.Popup.hide();return false;"';
	function doRawPopup(elPopupAnchor, iBacklog, ixBug, ixProject, fAdding, fGridView)
	{
		var maxBacklog = oSelf.rgBacklogs[ixProject] !== undefined ? oSelf.rgBacklogs[ixProject].length : 0;
		
		oSelf.Popup.setHtml(
			'<form id="backlogForm" onsubmit="return ProjectBacklog.submitPopup(' + ixBug + ', ' + ixProject + ', ' + (iBacklog.length > 0 ? iBacklog : 0) + ', ' + fGridView + ');">\n' + 
				'<h1><label for="iBacklogNew"><nobr>' + oSelf.l10n.BACKLOG_ORDER + '</nobr></label></h1>' + 
				'<div><input type="text" id="iBacklogNew" name="iBacklogNew" value="' + iBacklog + '" style="width:95%" maxlength="10" /></div>' + 
				'<div id="backlogError" style="display: none; color: red;">' + oSelf.l10n.ERR_INVALID_BACKLOG + '</div>' + 
				'<div class="editInstructions" style="margin-bottom: 8px;"><nobr>' + FB_PROJECT + ': ' + UnicodeClean(getRawProjectName(ixProject)) + ' ' + UnicodeClean(oSelf.l10n.BACKLOG_NUMBER_OF_CASES_FORMAT.replace('{0}', maxBacklog)) + '</nobr></div>' + 
				'<div class="backlogShortcuts">' +
				( fAdding ?
						(helpMove(oSelf.l10n.ADD_TO_TOP, 1, ixBug, ixProject, oSelf.UpArrow, iBacklog, fGridView) +
						helpMove(oSelf.l10n.ADD_TO_BOTTOM, maxBacklog + 1, ixBug, ixProject, oSelf.DnArrow, iBacklog, fGridView) )
					:
						(helpMove(oSelf.l10n.MOVE_TO_TOP, 1, ixBug, ixProject, oSelf.UpArrow, iBacklog, fGridView) + 
						helpMove(oSelf.l10n.MOVE_TO_BOTTOM, maxBacklog, ixBug, ixProject, oSelf.DnArrow, iBacklog, fGridView) +
						helpMove(oSelf.l10n.REMOVE_FROM_BACKLOG, '\'\'', ixBug, ixProject, oSelf.RemoveIcon, iBacklog, fGridView) )
				) +
				'</div>' + 
				'<br /><nobr><input type="submit" value="' + FB_OK + '" class="dlgButton"> ' + 
				'<input type="button" onclick=' + cancel + ' value="' + FB_CANCEL+ '" class="dlgButton"></nobr>' +
			'</form>');
		oSelf.Popup.showPopup(elPopupAnchor);
		return false;
	}

	function helpMove(sLabel, sVal, ixBug, ixProject, sIconHtml, iBacklog, fGridView)
	{
		function wrapA(s){
		    return '<a href="" style="text-decoration: none;" onclick="$(\'form#backlogForm input[name=&quot;iBacklogNew&quot;]\').val(' + sVal + ');return ProjectBacklog.submitPopup(' + ixBug + ', ' + ixProject + ', ' + (iBacklog.length > 0 ? iBacklog : 0) + ', ' + fGridView + ');">' + s + '</a>';
		}
		return '<div>' + wrapA(sIconHtml + ' ' + sLabel) + '</div>';
	}

	this.submitPopup = function (ixBug, ixProject, iBacklogOld, fGridView)
	{
		var sBacklogNew = $("form#backlogForm input[name='iBacklogNew']").val();
		var iBacklogNew = toInt(sBacklogNew);
		if(/^\s*$/.test(sBacklogNew) || (/^\s*\d+\s*$/.test(sBacklogNew) && iBacklogNew <= 0x7FFFFFFF) ){
			if (iBacklogNew < 1) {
				iBacklogNew = 1;
			}
			oSelf.Popup.hide();
			oSelf.setBacklogValue(ixBug, ixProject, iBacklogOld, iBacklogNew, fGridView);
		}
		else{
			$("#backlogError").show("normal", function(){oSelf.Popup.fixShadow();});
		}
		return false;
	};

	function getRawProjectName(ixProject)
	{
		var proj = DB.Project.select(function(row){return row.ixProject === ixProject});
		if(proj.length !== 1)
			return 'N/A';
		else
			return proj[0].sProject;
	}

	function errMsg(sClass)
	{
		$("div.projectBacklogGridContainer." + sClass)
			.parents("td")
			.click(function(){
				var sErr = "err";
				var sHeader = sErr;
				switch(sClass){
					case 'NotEditable':
						sErr = oSelf.l10n.ERR_BUG_NOT_WRITABLE;
						sHeader = oSelf.l10n.ERR_BUG_NOT_WRITABLE_HEADER
						break;
					case 'Closed':
						sErr = oSelf.l10n.ERR_BUG_CLOSED;
						sHeader = oSelf.l10n.ERR_BUG_CLOSED_HEADER;
						break;
				}
				
				oSelf.Popup.setHtml('<h1>' + sHeader + '</h1><div style="width:300px;color:red;">' + sErr + '</div><br/><div><form onsubmit=' + cancel+ '><input type="submit" onclick=' + cancel + ' value="' + FB_OK + '" class="dlgButton" /></form></div>');
				oSelf.Popup.showPopup(this);
			});
	}
	
	this.bindClickHandlers = function()
	{
		$("div.projectBacklogGridContainer.unbound")
			.removeClass('unbound')
			.parents("td")
			.css("cursor","pointer")
			.click(function(e){
				return oSelf.doGridPopup(this, e);
			});
		
		errMsg('NotEditable');
		errMsg('Closed');
	};
	
	$(document).ready(function(){
		oSelf.enable();
		oSelf.Popup = api.PopupManager.newPopup("ProjectBacklog");
	});
}();
