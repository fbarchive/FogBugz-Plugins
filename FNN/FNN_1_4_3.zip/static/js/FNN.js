﻿function fnn_AddPluginPrefix(controlName) {
    return fnn_getPlugInPrefix() + controlName;
}

function fnn_updateContent() {
    fnn_beforeUpdate();
}

function fnn_beforeUpdate() {

    //disable submit button
    $("[name$='" + fnn_AddPluginPrefix("btnRefresh") + "']").attr('disabled', 'disabled');
    
    //fade-out content, fade-in busy icon, kick off update
    $('#dataContent').fadeTo('fast',.33,
                              function() {
                                  $('#loadingImage').fadeIn('fast', fnn_startUpdate);
                              }
                             );
}

function fnn_startUpdate() {
    updateInProgress = true;
    var ajaxURL = fnn_PostBackURL() + $("#frmControls").serialize();
    $("#dataContent").load(ajaxURL, {}, fnn_afterUpdate);
}

function fnn_afterUpdate() {

    //fade-out busy-icon, fade-in conent
    $('#loadingImage').fadeOut('normal',
                                function() {
                                    $('#dataContent').fadeTo('fast',1);
                                }
                                );
   //re-enable submit button                             
   $("[name$='" + fnn_getPlugInPrefix() + "btnRefresh']").removeAttr('disabled');
   fnn_addTableSorter();
   updateInProgress = false;   
}

function fnn_startExport() {
    var exportURL = fnn_PostBackExportURL() + $("#frmControls").serialize();
    window.location.href = exportURL;
}

function fnn_addTableSorter() {
    $("table[id$='_sortable']").addClass('tablesorter')
                               .tablesorter(fnn_sortSpec())
                               .bind("sortEnd", function() { fnn_alternateRowColors($("table[id$='_sortable']")); });
}

function fnn_alternateRowColors(tableElement) {
                                            tableElement.children("tbody").children("tr:odd").addClass("r-a").removeClass("row");
                                            tableElement.children("tbody").children("tr:even").addClass("row").removeClass("r-a")
}

//subscription screen
function fnn_unsubscribe(ixSubscription) {
    $('#' + fnn_AddPluginPrefix('ixUnsubscribeID')).val(ixSubscription);    
    fnn_updateContent(); 
}

// FNN RecentEventsScreen
var updateInProgress=false;

function fnn_fullRefresh() {
   var refreshButton =  $("[name='" + fnn_getPlugInPrefix() + "btnRefresh']"); 
   refreshButton.click(); 
}

function fnn_autoRefreshChecked() {
    var chkAutoRefresh = $("[name='" + fnn_getPlugInPrefix() + "autoRefresh']");    
    return chkAutoRefresh.length>0 && chkAutoRefresh.attr('checked');
}

var lastFormData='';

function fnn_StartUpdateContentPartial() {
     if (!fnn_autoRefreshChecked()) {return;}    
     if (updateInProgress) { return; }

     var formData = $('#frmControls').serialize();
     if (formData != lastFormData) {
         //filter criteria changed. Initate a full refresh
         lastFormData = formData;
         fnn_fullRefresh();
         return;
     }
     
     updateInProgress = true;

     var ajaxURL = fnn_PostBackURL() + formData;
     var lastBugEvent= $('#ixLastBugEvent').val();
     if (lastBugEvent=='') {lastBugEvent='0'}
     ajaxURL += '&' + fnn_getPlugInPrefix() + 'ixLastEventID=' + lastBugEvent.toString();
     $.get(ajaxURL, {}, function(data) {fnn_afterUpdatePartial(data);});
 }

 function fnn_stripeInsertedRows(insertedRows,oldTopRow) {
         var isEvenInsert = (insertedRows.length%2)==0;
         var isTopRowAlternate = oldTopRow.hasClass("r-a");
         
         if ((isEvenInsert == isTopRowAlternate)|| (!isEvenInsert && !isTopRowAlternate)) {
             insertedRows.filter(":even").addClass("r-a").removeClass("row");
             insertedRows.filter(":odd").addClass("row").removeClass("r-a");             
          }
          else {
             insertedRows.filter(":even").addClass("row").removeClass("r-a");
             insertedRows.filter(":odd").addClass("r-a").removeClass("row");             
         }
 }

 function fnn_afterUpdatePartial(data) {
     var tableBody = $('#staticeventData>tbody');
     var newRows = $(data).find('tbody>tr:not(.noresults)').addClass("fnnInsertedRows");

     if (newRows.length > 0) {
         var topRow = tableBody.find("tr:first");
         $('#ixLastBugEvent').val($(data).find('#ixLastBugEvent').val());

         var maxRows = parseInt($("[name='" + fnn_getPlugInPrefix() + "rowCount']").val());
         newRows.filter(':not(.noresults)').prependTo('#staticeventData>tbody');
         tableBody.find('tr:gt(' + (maxRows-1).toString() + ')').remove();

         var insertedRows = $("tr.fnnInsertedRows");
         fnn_stripeInsertedRows(insertedRows, topRow);
         insertedRows.removeClass("fnnInsertedRows");
     }
     updateInProgress=false;
}
            