FNN - FogBugz News Network
======================
The FNN FogBugz plugin provides additional reporting functionality to FogBugz to better enable you to keep tabs on your projects.

Installation
===========
Use the upload plug-in button on the FogBugz plug-in page and select the FNN.zip file you downloaded from the plug-in gallery.

IMPORTANT: You have to upload the entire zip file for the plug-in to work. 
  
Pre-Requisites
==============
The Work in Progress report will only work correctly with FogBugz version 8.3.42 or later.
  
Configuration 
==============
No configuration is provided or needed.

Usage
=====
Look for the extra menu item(s) on the "Extras" menu with the "FNN" prefix. 
Case headers will also display the names of users who currently have it marked as their "working on" case.

Release Notes
---------------------
** Version 1.4.3 **
Fix: Deleted Groups no longer show up in the user dropdown in the report criteria.

** Version 1.4.2 **
Fix: Fixed sorting in user list

** Version 1.4.1**
Fix: Fixed error in Activity Summary report


** Version 1.4.0 **
Feature: Activity Report has been split into two versions, detail and summary.
Feature: Detail Activity report now allows you to filter the report only to subscribed cases.
Fix: The user filter option now lists the names in alphabetical instead of random order.

** Version 1.3.3 **
Fix: Filtering reports on "Everyone Except -FogBugz-" was not working correctly.
Change: Activity report will now work even if end date is before begin date.
Change: Recent Events "Auto-Refresh" feature will now adjust for changed filter criteria without requiring you to hit the refresh button after the change.

** Version 1.3.2 **
Fix: Fixed conflict with TemplateNotification plugin (and possibly others) that prevented user dropdown from displaying.
Fix: Fixed some cosmetic issues on report criteria control area.

** Version 1.3.1 **
Feature: Added person filter on Working on Report.

** Version 1.3.0 **
Feature: Reports can now be filtered by groups.
Feature: Activity Report can now be filtered by the type of update
Feature: All reports can now be exported to Excel (CSV file)
Feature: Subscription report can not be filtered by subscription type (Case,Discussion Topic, Wiki)
Change: Subscription Report now defaults to showing only the current user instead of everyone (for performance reasons)
Change: Subscription and Activity Report will now show only the first 500 rows (for performance reasons)
Fix: Compatibility changes in preparation for for 8.7.16 release of FogBugz.

** Version 1.2.4 **
Fix: Fixed issue with auto-refresh on Recent Events Screen
Tweak: Improved performance on Recent Events Screen

** Version 1.2.3 **
Fix: If the DB has unlinked wiki articles with subscriptions, the app was throwing a null-reference error.
Fix: Fixed time-zone conversion on Recent Events and Activity Report to convert to client's time zone instead of server's.

** Version 1.2.2 **
Fix: A few significant bug fixes. (Thanks for reporting the issues Jude!)

** Version 1.2.1 **
Feature: New Activity Report enabling you to create a report on events for a custom date range.
Feature: New Subscriptions Report shows who is subscribed to which case and lets you unsubscribe them right from the report.
Feature: Recent Events report now has an auto-update feature to provide a ticker (5 second delay) of events as they happen.

Update: Recent Events report now has option to show up to 1000 most recent items (previous limit was 100).
Update: Reports now fall-back to a backup source for the Update Notes column when the primary source is blank. You will see fewer empty cells in this column.


** Version 1.1.6 **
Fix: On some installations of FogBugz, reports would thow 'Ambiguous column name 'ixPerson' exception.

** Version 1.1.5 **
Fix: Extras menu options are no longer displayed to anonymous and community users. In previous versions they were displayed, but did nothing.

** Version 1.1.4 **
Fix: Fixed encoding issue for names with diacritics in "Working On" indicator on bug display.
Fix: Work In progress Report now sorts in ascending order instead of descending order on name.

** Version 1.1.3 **
Fix: Removed dependency which was causing error on FB Installations without the .NET 3.5 framework installed. 
If you were getting the "System.IO.FileNotFoundException: Could not load file or assembly 'System.Data.DataSetExtensions, Version=3.5.0.0.." error on 1.1.2 you can either install the .NET 3.5 update or upgrade to this version.

** Version 1.1.2 **
Fix: Times on Recent Events report are now displayed in local time instead of UTC.

** Version 1.1.1  **
Urgent Fix: Fixed a problem where the plug-in was causing the bug view and edit pages to time out on Internet Explorer.
Fix: Fixed calculation of remaining hours on "Work in Progress" report to handle cases with a zero hour time estimate.

** Version 1.1.0 **
New Feature: Work In Progress Report
New Feature: Added Working on indicator to case display.

Bug Fix: Fixed error when accessing recent events screen "Wasabi.Runtime.WasabiException (0x80004005): Ambiguous column name 'ixproject'."

** Version 1.0.0 (Initial Release) **
Feature: Recent Events Report Added


Enjoy!

John Fuex 
john.fuex@gmail.com
http://improvingsoftware.com