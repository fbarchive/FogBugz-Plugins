﻿var EventHider = EventHider || (function() {
	var rgIxHiddenEvent = [];
	var fDocReady = false;
	var sLabel = null;
	$(document).ready(function() {
		function init() {
			var cLen = rgIxHiddenEvent.length;
			if (cLen === 0) { return; }
			sLabel = sLabel || 'hiding ' + cLen + ' minor edit' + (cLen === 1 ? '' : 's');
			$('#bugviewContainerSide').append($('<div id="TidyCaseEvents_Container"><label>Tidy Case Events</label><div class="content"><a id="TidyCaseEvents_Unhide" class="dotted" style="text-decoration: none; font-size: 10px;" href="javascript:void 0;">' + sLabel + '</a></div></div>'));
			$('#TidyCaseEvents_Unhide').click(function(ev) {
				ev.preventDefault();
				
				$.each(rgIxHiddenEvent, function() {
					$('#bugevent_' + this).stop(true, true).effect('highlight', {}, 4000);
				});
				sLabel = 'highlight minor edits';
				$(this).text(sLabel);
			});
		}

        $(".TidyCaseEvents_hideEventInfo").each(function (el) {
            EventHider($(this).data('ixbe'));
        });

		fDocReady = true;
		init();

		$(window).bind("BugViewChange", function() {
			//BugViewChange?  Our container may have been deleted. Reinit!
			if (!$('#TidyCaseEvents_Container').length) {
				init();
			}
		});
	});
	return function(ixbe) {
		//Events added after document-ready don't get hidden.
		if (fDocReady) { return; }

		$('#bugevent_' + ixbe).hide();
		rgIxHiddenEvent[rgIxHiddenEvent.length] = ixbe;
	};
} ());

var tidyCaseEventsSettings = {
	rawPageURL: "",
	token: ""
};

$(function() {
    if ($("#tidyCaseEventsConfigPage").length) {
        $('#bulkEnable').click(function(){
            $('input', '#mainArea').not(':checked').attr('checked','checked');
            $('#labelSaved').hide();
        });
        $('#bulkDisable').click(function(){
            $('input', '#mainArea').filter(':checked').removeAttr('checked');
            $('#labelSaved').hide();
        });
        $('input', '#mainArea').change(function(){
            $('#labelSaved').hide();
        });
        $('#buttonSave').click((function(){
            function updateLabel(){
                $('#buttonSave').val(state);
            }

            var state = 'Save';

            return function(){
                if(state === 'Save') {
                    state = 'Saving...';
                    updateLabel();
                    $('#labelErr').hide();
                    var sIxEnabled = $.map($('input', '#mainArea').filter(':checked'), function(jCheckbox, ix){return $(jCheckbox).attr('name');}).join();

                    $.post(
                        tidyCaseEventsSettings.rawPageURL,
                        {
                            'On': sIxEnabled,
                            'sToken': tidyCaseEventsSettings.token
                        },
                        function(data){
                            if(data === 'OK') {
                                $('#labelSaved').show();
                            } else {
                                $('#labelErr').show();
                            }
                            state = 'Save';
                            updateLabel();
                        }
                    );
                }
            };
        }()));
    }
});