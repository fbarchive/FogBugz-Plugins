﻿/*
 * Organizations.js
 *
 *		This file contains the javascript functions used to support the 
 *	organization plugin.
 *
 *
 *	- Dynamically Updating the Fogbugz Menus -
 *
 *		Most of the Fogbugz menus get changed on an Javascript call which is
 *	invoked when a menu option is selected.  We can make
 *	Fogbugz put whatever contents we need into its menus by simply
 *	altering the hidden menu item, and invoking the Fogbugz menu update functions.
 *
 *		The 'value' attribute of each option in the organization menu contains the
 *	inner HTML of a select element.  This select element holds all of the projects
 *	that are currently assigned to the selected organization.  We take this HTML and
 *	use it to create the new Project menu each time the organization menu is clicked by 
 *	using it to replace the HTML in the hidden project menu.
 *
 *
 *	- Organizations Template System -
 *
 *		Templates are made available via a set of hidden text elements that get created
 *	by the C# code in the "bug display" interface implementation.  These templates have an
 *	element id naming convention of:
 *										orgName_template
 *
 *		When an organization is selected, the current text is stored in its respective template
 *	text area (this is done so information is not lost if the user accidentally selects the wrong
 *	organization).  Then the text in the template textbox for the selected organization is used
 *	to populate the description text area.
 *
 *
 *
 *	@author Matt Huotari
 *	@modify 06/21/2010
 *
 */

window.onload = initOrgPluginBugGUI;

// This is the name of the organization whos template is currently being displayed
var organizationTemplateSet = null;

/*
 * initOrgPluginBugGUI
 *
 *	Initalizes the edit bug GUI elements associated with the 
 *	plugin.
 *
 *	@param
 *		timeout - Currently used to indicate if this function
 *				  is on its last attempt to initalize the GUI
 *				  changes.  Should be 'Failed' if the function
 *				  should not set a timer again, or empty otherwise.
 *
 */
function initOrgPluginBugGUI(timeOut) {

	// Fixes the filter display that's broken when using plugin filters for some reason
	var sFilterOptionsHTML = $('#idFilterOptToolbarActions').html();
	var iFilterIdIndex = 0;
	
	if (sFilterOptionsHTML) {
		iFilterIdIndex = sFilterOptionsHTML.indexOf("ixFilter=") + 9;
	}
	
	if (iFilterIdIndex > 0 && $("#idFilterTitle").html() == "Filter") {
	
		sFilterOptionsHTML = sFilterOptionsHTML.substring(iFilterIdIndex);
		var iFilterIdEndIndex = sFilterOptionsHTML.indexOf("&amp;sSignature=");
		var ixFilter = sFilterOptionsHTML.substring(0, iFilterIdEndIndex);
		var sTitle = "Filter";

		$("#filterPopup a").each( function(index) {
		
			var iFound = $(this).attr("href").indexOf("ixFilter=" + ixFilter);
			
			if (iFound > 0) {
				
				sTitle = $(this).html().substring($(this).attr("href").indexOf(">") + 1);
			}
		});
		
		$("#idFilterTitle").html(sTitle);
	}
		
	var orgMenu = document.getElementById("sOrganization");
	
	// Check if the organzation menu is on the page
	if (orgMenu) {
	
		// The organizations menu is present, we need to start working on the GUI
		
		// Check for IE
		if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)){
			var ieversion=new Number(RegExp.$1);
			if (ieversion>=8){}
			else if (ieversion>=7){}
			else if (ieversion>=6) {
		
				// This plugin does not support IE 6
				orgMenu.parentNode.parentNode.innerHTML = "";
				return false;
			}
		}
		
		// Find the "status" drop-down menu's container element
		var statusText = document.getElementById("ixStatus").parentNode.parentNode;
		
		// If the status menu container is 'plugins' class, then we've already updated
		// the GUI, no work needs to be done at the moment
		if (statusText.className.indexOf("plugins edit") != -1) {
		
			// We're going to sleep for 3 seconds and then check for any changes made
			// by any FB AJAX calls (this is done because the GUI can change without reloading
			// the page, and thus our javascript won't get invoked).
			setTimeout("initOrgPluginBugGUI()",3000);
			
			
			return true;
		}
		
		// Reorganize the menus so organizations is on top
		
		// Get the org menu container element
		var theParentDiv = orgMenu.parentNode.parentNode;
		
		var projectChild = document.getElementById("ixProject");
		projectChild = projectChild.parentNode.parentNode;
		
		// The top-level container for the top part of the Bugz GUI
		var topParentDiv = projectChild.parentNode;

		topParentDiv.insertBefore(theParentDiv,projectChild);

		// Move the "status" drop-down to the 3rd row by making its
		// parent a plugins edit class container
		statusText.className = "row3 plugins edit";

		// Force an update of the project menu by clicking on the org menu
		orgMenuClick(orgMenu);
		
		// Sleep for 3 seconds and then check for an AJAX update
		setTimeout("initOrgPluginBugGUI()",3000);
	}
	else if (document.getElementById("bugviewContainerTop")) {
		// The user may be editing a bug, sleep for 1 second and then
		// check for an AJAX update
		setTimeout("initOrgPluginBugGUI()",1000);
	}
	else {
		// We have given up on this page because it looks like the Bugz
		// GUI will never be present
		if (timeOut == 'Failed')
			return true;
		
		// We have failed to find the Bugz GUI, perhaps the page is still
		// loading because we caught it in the middle of something?
		// Try one more time.
		setTimeout("initOrgPluginBugGUI('Failed')",2000);
	}
}

/*
 * orgMenuClick
 *
 * @params
 *			orgMenuElement - A reference to the org menu
 *
 *
 *	Event handler for when the organization menu is clicked on
 *  and changed.
 *
 *
 */
function orgMenuClick(orgMenuElement) {

	// This select element will replace the one currently in the project menu cache
	var projectSelect = orgMenuElement.value;
	
	// Get the organzation menu dropdown element
	var orgDisplay = document.getElementById("idDropList_sOrganization_oText");
	
	// Extract the name of the visible organization list
	var orgName = orgDisplay.value;
	cacheOrgTemplate(orgName);
	
	// Retrive location of the inner HTML we'll be inserting into the project cache
	var startInnerHTML = projectSelect.indexOf("<option value=");
	var endInnerHTML = projectSelect.indexOf("</select>");
	
	// Extract the HTML that will go in the project menu
	projectSelect = projectSelect.substring(startInnerHTML, endInnerHTML);
	
	// Update the hidden organization field
	setOrgField(orgName);
	
	// Get the project menu element cache so we can modify its options
	var projectMenu = document.getElementById("sProject");
	
	// Check that the cache exists, then replace its innerHTML with our new Project menu.
	// This is a messy-looking process.
	if (projectMenu) {
		var ProjMenuParent = projectMenu.parentNode;
		var parentInnerHTML = projectMenu.parentNode.innerHTML;

		startInnerHTML = parentInnerHTML.indexOf("<OPTION");
		if (startInnerHTML < 0) {startInnerHTML = parentInnerHTML.indexOf("<option");}

		endInnerHTML = parentInnerHTML.indexOf("</select>");
		if (endInnerHTML < 0) {endInnerHTML = parentInnerHTML.indexOf("</SELECT>");}

		var newINNERHTML = parentInnerHTML.substring(0, startInnerHTML);
		newINNERHTML += projectSelect;
		newINNERHTML += parentInnerHTML.substring(endInnerHTML);
		ProjMenuParent.innerHTML = newINNERHTML;

		var projectMenu2 = document.getElementById("ixProject");
		var defaultSelected = projectMenu2.value;

		ProjMenuParent = projectMenu2.parentNode;
		parentInnerHTML = projectMenu2.parentNode.innerHTML;

		startInnerHTML = parentInnerHTML.indexOf("<OPTION");
		if (startInnerHTML < 0) {startInnerHTML = parentInnerHTML.indexOf("<option");}

		endInnerHTML = parentInnerHTML.indexOf("</select>");
		if (endInnerHTML < 0) {endInnerHTML = parentInnerHTML.indexOf("</SELECT>");}
		var newINNERHTML = parentInnerHTML.substring(0, startInnerHTML);
		newINNERHTML += projectSelect;
		newINNERHTML += parentInnerHTML.substring(endInnerHTML);
		ProjMenuParent.innerHTML = newINNERHTML;

		
	}
	else {
		// This is a serious problem, this message box should not appear
		// Could indicate a change in element IDs
		alert("Organizations - Project Menu Not Found");
	}
	
	var projectActiveMenu = document.getElementById("sProject");
	
	// Click on our new project menu to update the rest of the menus in the bugz GUI
	projMenuClick(projectActiveMenu, defaultSelected);
}

/*
 * setOrgField
 *
 * @params
 *			orgName - the name of the selected organization
 *
 *
 *	Sets the hidden organization filed to the currently
 *	selected organization.
 *
 */
function setOrgField(orgName) {
	var orgField = document.getElementById("sOrgStringName");
	orgField.value = orgName;
}

/*
 * setOrgTemplate
 *
 * @params
 *			orgName - the name of the organization
 *
 *
 *	Trys to retrive the template text for the given organization
 *  using a hidden input that was created by the plugin.  Then 
 *  updates the description text field with the template.
 *
 */
 function setOrgTemplate(orgName) {
	var orgTemplateField = document.getElementById(orgName + "_template");
	
	// Update only if we organizations have changed
	if (orgTemplateField && organizationTemplateSet != orgName && orgTemplateField.value != "") {
		var caseDescription = document.getElementById("sEventEdit");
		var templateText = orgTemplateField.value
		
		// Compensate for IEs problem with textbox newlines
		templateText = templateText.replace(/%0A/g, "\n");
		caseDescription.value = templateText;
		organizationTemplateSet = orgName;
		
		// FB textarea update function
		adjustRows(caseDescription);
	}
 }
 
 /*
 * cacheOrgTemplate
 *
 * @params
 *			orgName - the name of the organization
 *
 *
 *	Trys to cache the current description text box so it can be
 *	retrived when the user comes back to the given organization.
 *	This is done to allow users to recover their work if they
 *	chose the wrong organization to begin with.
 *
 */
 function cacheOrgTemplate(orgName) {
 	var orgTemplateField = document.getElementById(orgName + "_template");
 	
 	// Only cache if the given organization is actually the active one
	if (orgTemplateField && organizationTemplateSet == orgName) {
		var caseDescription = document.getElementById("sEventEdit");
		if (caseDescription.value != "") {
			var templateText = caseDescription.value;
			
			// Compensate for IEs problem with textbox newlines
			templateText = templateText.replace(/\n/g, "%0A");
			orgTemplateField.value = templateText;
		}
	}
 }

/*
 * projMenuClick
 *
 * @params
 *			projMenuElement - A reference to the hidden project menu
 *			defaultVal		- The value to set this menu to by default
 *
 *
 *	Event handler for when the organization menu is clicked on
 *  and changed.  This simulates a click on our hidden project menu.
 *
 */
function projMenuClick(projMenuElement, defaultVal) {

	var projectMenu = document.getElementById("idDropList_ixProject_oText");

	// Get the modified project menu and find the project we should select first
	var projectMenuList = document.getElementById("ixProject");
	var projMenuOpts = projectMenuList.options;
	var defaultProjectIndex = -1;
	var currentlySelectedProject = -1;
	
	// Iterate through each option in the project menu
	for (var i = 0; i < projMenuOpts.length; i++){
		var curVal = projMenuOpts[i].value;
		
		// Check to see if the current value is the default value
		// This tells us the option index of our default value
		if (curVal == defaultVal) {
			defaultProjectIndex = i;
		}
		else if (curVal == projMenuElement.value) {
			// This is the option index of the crurently selected value
			currentlySelectedProject = i;
		}
	}
	
	// If we were unable to locate the option index of our default value, then
	// we'll revert to our currently selected value
	if (defaultProjectIndex < 0)
		defaultProjectIndex = currentlySelectedProject;
		
	// Ensure the project menu is available
	if (projectMenu) {
	
		// Ensure we were able to find a valid option index to use
		if (defaultProjectIndex >= 0) {
		
			// Designate the option at our selected index as "selected"
			projMenuOpts[defaultProjectIndex].selected = true;
			
			// Invoke the Fogbugz project changed function to refresh the other menus based on our
			// selected project
			projectChanged(defaultProjectIndex);

			
			// For some reason the call to projectChanged generates an extra nobr tag, we gotta
			// get rid of it because it ruins the Bugz GUI
			elemId = "ixProject";
			projectMenu = document.getElementById(elemId);
			var thatExtraNobrTag = projectMenu.parentNode;
			thatExtraNobrTag.removeChild(thatExtraNobrTag.firstChild);

			projectMenu.value = projMenuOpts.value;
		}
		else {
			// We failed to locate a valid index, indicate an error.  This should never happen,
			// and represents a problem somewhere in the previous code, perhaps in the inner
			// HTML construction phase.
			projectMenu.value = "[Error]";
		}
	}
	
	// Try to load the template of the selected organization
	var orgMenuElement = document.getElementById("sOrganization");
	var selectedOrgName = orgMenuElement.options[orgMenuElement.selectedIndex].innerHTML;

	// Now that we're all done updating, set the description text to the correct template
	setOrgTemplate(selectedOrgName);

	if ($('#sEventEdit').is(":visible")) {
		$(window).trigger('BugViewChange');
	}
	
	// Remove the extra selector that gets added for some reason
	$('.editModeSelector').each(function(i, obj){
		if (i != 0) {
			$(obj).remove();
		}
	});

}