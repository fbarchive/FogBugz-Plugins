$(function (){
    var cMaxBytes = 5000 * 1024;
    var sWarning = "File is larger than the maximum allowed attachment size in Salesforce";
    var rgPostFix = [["MB", 1024 * 1024], ["KB", 1024], ["B", 1]];
    if (!$("iframe[name=attachFrame]").length) return;
    setInterval(function() {
        $("#files_list").find("div.attachmentBlock:not(.hasSize)")
        .each(function() {
            var fs = this.element.files;
            if (!fs) return;
            var cBytes = fs[0].size;
            var sBytes;
            $.each(rgPostFix, function(ix, el) {
                if (cBytes >= el[1]) {
                    sBytes =
                        Math.round(cBytes / el[1] * 100) / 100 + " " + el[0];
                    return false;
                }
            });
            $("<span>")
            .css("margin", "4px")
            .css("color", cBytes > cMaxBytes ? "#f00" : "#000")
            .attr("title", cBytes > cMaxBytes ? sWarning : "")
            .text("(" + sBytes + ")")
            .appendTo($(this).find("nobr"));
        })
        .addClass("hasSize");
    }, 1000);
});


$(function (){
    try {
        $('.dialog').each(
          $('.content').each(
             function (index) {

                 var value = $(this).text();

                 if (value.indexOf("_SFLookupField") >= 0) {
                     var myarr = value.split("_");
                     var count = myarr.length;
                     if (count == 3) {
                         value = myarr[1];
                     } else {
                         value = myarr[1];
                         for (var i = 0; i < count - 3; i++) {
                             value += "_" + myarr[i + 2];
                         }
                     }
                     $(this).html(value);
                 }
             }));
     }catch(err){}
});