﻿$(document).ready(function() {
                        fbso_scratchAttachmentsAsNeeded();
                        fbso_scratchHeaderAsNeeded();                        
                  }
                 );

function fsbo_toggleScratchout(callbackBaseURL, refreshURL,pluginPrefix, isScratchedOutNew) {
    
    //not available in edit mode
    if (fbso_isEditMode()) {        
        alert("You can't scratchout or restore while editing the case.");
        return false;
    }

    var reason = "";
    if (isScratchedOutNew) {
        reason = prompt("Why are you scratching this out?", '');
        if (reason == null) { return; }
    }

    var callbackURL = callbackBaseURL + "&" + pluginPrefix + "sReason=" + escape(reason);

    jQuery.get(callbackURL, function (data) {
                                    window.location.replace(refreshURL);           
                            }
    ); 

    return false;
}

function fbso_getNoCacheValue() {
   var d = new Date();
   return d.getTime().toString();    
}

function fbso_isEditMode() {
    //this may need to be updated if FB changes HTML or behavior, but it is necessary until this functionality is available in the API.
    return ($("textarea[name=sEvent]").length > 0);
}

function fbso_canScratchOut(obj) {
    // if the object has a toggleheader and the form isn't in edit mode, scratch out is available.
    return !fbso_isEditMode() && $(obj).find(".ToggleHideLink").length;
}
                  
function fbso_setScratchLinkVisibility() {
    fbso_ToggleLinkHeaders(!fbso_isEditMode()); 
}

function fbso_ToggleLinkHeaders(visible) {
    $("a.ToggleHideLink").toggle(visible);
}

function fbso_scratchAttachmentsAsNeeded() {
    // process attachments that need to be hidden
    $("input.scratchedOutFlagHide").each(function () {
        var bugEventID = this.value;
        $('#bugevent_' + bugEventID.toString() + ' > div.attachments').hide();
    });

    //process attachments that need to be scratched out.
    $("input.scratchedOutFlagScratch").each(function () {
        var bugEventID = this.value;
        $('#bugevent_' + bugEventID.toString() + ' > div.attachments').addClass('Scratchedout');
        $('#bugevent_' + bugEventID.toString() + ' > div.attachments').find('img').addClass('ScratchedoutImage');
    });

    return;
}

function fbso_scratchHeaderAsNeeded() {
    $("div.ScratchedoutPlaceHolder,div.Scratchedout").closest(".bugevent").find(".action,.date").addClass("ScratchedoutHeader");
}