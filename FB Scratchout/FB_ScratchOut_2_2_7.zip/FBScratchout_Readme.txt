FogBugz Scratchout Plug-in
===========================
The purpose of this plug-in is to allow you to visibly deprecate events in the case history when using FogBugz without permanently deleting them.

The most common scenarios where this might be useful are:
* History entries added to the wrong case. You no longer need to clutter the case further with a second "ignore that" entry.
* Clearly marking discussions that are no longer relevant because the resolution took a left turn and went in a different direction. This can really help testers quickly ignore irrelevant material when reading through the case to see what was changed.
* Any other mistakes or reasons that make you wish FB had a delete button.


Installation
===========
Just use the upload plug-in button on the FogBugz plug-in page and select the FB_Scratchout.zip file you downloaded from the plug-in gallery.

MPORTANT: You have to upload the entire zip file for the plug-in to work.
 
 
Configuration 
==============
There are two configuration options available from the link on the plug-ins screen of FogBugz.

	Manage FogBugz Plug-in Separately for each project
	--------------------------------------------------
	Disabled (Default) - FB Scratchout is available on all projects.
	Enabled - A new configuration setting is added on the FogBugz Project page to turn FB Scratchout on/off on a per-project basis.

	Style for Scratched out events
	------------------------------
	Strikeout (default) - Scratched out events are still displayed with a strike through effect. A tool tip will display the scratchout reason if available.
	Placeholder - Replaces the case text with [Scratched Out: {reason}]. This style is much more compact and doesn't require a mouse-over to see the scratchout reason.


Usage
=====
Just mouse over an event in the case history that has any textual content and you will either see a Scratchout or a Restore button depending on whether that event has already been scratched out. 

Click that link to toggle the scratchout status. If you are scratching out you will be prompted at this time for an optional reason for the scratchout.

Note: If you don't see the button appear, make sure the project has FB Scratchout enabled or it is enabled for all projects.

Known Issues
---------------------
E-mail header information is not scratched out with rest of message.


Release Notes
---------------------
** Version 2.2.7 **
   Fix: Compatibility bug with Case merge plugin. FB Scratchout will now work for events pulled in from a duplicate bug because of the merge plugin.

** Version 2.2.6 **
   Fix: Bug that made the scratchout link hidden when it shouldn't be.

** Version 2.2.5 **
   Fix: Previous build was incorrectly marked as compatible with FogBugz 7.3+, but in fact was only compatible with FogBugz 8.3.42 or later.

** Version 2.2.4 **
   Fix: Fixed formatting issues for newer versions of FogBugz (Removed extra padding on case events with no content)
   Fix: Scratchout button would sometimes be incorrectly wrapped to next line under header.
   Change: Attachments and images on case events can now be scratched out or faded depending on scratchout style.

** Version 2.2.3 **
   Fix: When enabled, case bodies would be mangled or invisible in Internet Explorer 9.
   Fix: When replying to a case the scratchout icon was sometimes misplaced.
   Optimization: Client side scripting logic has been optimized and should be more performant on cases with lots of entries.

** Version 2.2.2 **
   Fix: After editing a case, the scratchout link for the newly edited item was displayed underneath the case header instead of in it.
   
** Version 2.2.1 **
   Fix: Attachment area of cases is now hidden for scratched out cases (regardless of scratchout style selected)
   Change: The scratchout/restore buttons are now shown in the header of the case event instead of beside it.
   Change: Mouseover effect (blue background) on case events has been removed.
   Change: Header of case event is now shown with strikethrough effect for scratched out cases (regardless of scratchout style selected).
   Change: You can now scratch out events that don't have any text in them. For example a case entry with only a screenshot.

** Version 2.1.6 **
   Fix: If multiple users scratchout out the same item concurrently. FBSO would start throwing an error on the case "Unable to query scratchedout events. Detail - An item with the same key has already been added."
   
** Version 2.1.5 **
   Fix: Incorrect case in script and css files caused issues on FogBugz installations running on a Unix platform.

** Version 2.1.4 **
   Fix: FogBugzSecurityException thrown if "Manage Scratchout plugin separately for each project" setting was turned on and community or anonymous user tried to check the status of a case using a ticket number.

** Version 2.1.3 **
   Fix: Error when restoring events on FogBugz installations where the default collation is set to case-sensitive (should be rare).
   Feature: Added support for scratching out case entries that were e-mailed directly into FogBugz. 

** Version 2.1.2 **
   Fix: "The user does not have permission to read this object." error when viewing or submitting anonymous case.

** Version 2.1.1 **
   Fix: Mouse-over effect was re-flowing the page which caused an annoying flicker and slow update. Replaced with background color change on mouseover.
   Fix: Scratching-out or restoring an entry directly after an edit caused a browser prompt about re-posting data. Fixed.
   
** Version 2.1.0 **
   Feature: Scratchout now tracks and displays the name of the person who scratched out an item.

** Version 2.0.1 **
   Fix: Incorrect e-mail address in link on Plugin configuration page.
   Fix: Deployment package had a few files in the wrong location causing the links to not show correctly.
   
** Version 2.0.0 **
   Feature: Scratchout and restore links now are only displayed when you mouse over an event that can be scratched out.
   Feature: Added the "Placeholder" scratchout style and a configuration screen to set the style used. No more CSS editing required.
   Feature: Added the option to disable FB Scratchout on a per project basis.   
   
   Fix: Confirmation dialog error that was fixed in 1.1.1 returned in 1.1.2 (oops).

** Version 1.1.3 **
	Fix: problem rendering scratched out events that included hyperlinks.
	
** Version 1.1.2  **
	Fix: problem where anonymous users submitting bugs received an "The user does not have permission to read this object." error after submitting a case or checking the status of an existing case.

** Version 1.1.1  **
	Fix: In FireFox 3.5 a horizontal scroll bar appeared when scratching out an event.
	Fix: Scratching out or Restoring an event caused FireFox to throw a confirmation dialog about refreshing the page.
	Fix: Toolbar image was in the incorrect directory in the Zip package and thus didn't display correctly.

** Version 1.1.0 **
	Feature: Replaced "Scratchout" link with button to reduce the clutter when viewing a case with many event entries.




Enjoy!

John Fuex 
john.fuex@gmail.com
http://improvingsoftware.com