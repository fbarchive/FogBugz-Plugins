﻿/* Globals
 * We've generated the following variables to help us out:
 * var CaseEventEdit_sPluginPrefix
 * var CaseEventEdit_sActionToken
 * var CaseEventEdit_sRawPageURL
 * var CaseEventEdit_sHTMLIconAttach
 * var CaseEventEdit_sHTMLIconTrash
 * var CaseEventEdit_sHTMLIconLoading
 * var CaseEventEdit_fBulkEdit
 */

//Bulk Edit Disabler:
//If I'm bulk-editing, get rid of the edit icons.
//All sorts of crazy stuff can happen, so we must do this continuously. 
//ATM, this must be done in Javascript.
$(document).ready(function() {
    if (typeof(CaseEventEdit_fBulkEdit) != "undefined" && CaseEventEdit_fBulkEdit) {
        setInterval(function() {
            $('[id^="CaseEventEditIcon"]', '#bugEventHistory').remove();
            $('[id^="CaseEventEditIcon"]', '#BugEvents').remove();
        }, 50);
    }
});

//CaseEventEdit Class:
var CaseEventEdit = CaseEventEdit ? CaseEventEdit : function() {

    //Private members:

    var Historian = ConstructHistorian();
    var Editor = ConstructEditor();
    var hashBEToEdit = {}; //dictionary of bugevent : ixedit.
    var sREQUESTFAIL = 'Server not responding... Refreshing this page might help.';

    //Public accessors:
    var members = {
        MakeEditable: Editor.MakeEditable,
        Edit: Editor.EditCaseEvent,

        ToggleHistory: Historian.ToggleHistory,
        ShowHistory: Historian.ShowHistory,
        HideHistory: Historian.HideHistory,
        RefreshHistoryFromSelectObj: Historian.RefreshHistoryFromSelectObj,

        ScrollTo: ScrollTo,
        hash: hashBEToEdit,
        FixImages : FixImages
    };

    //Utilities:
    function Prefix(s) {
        return '&' + CaseEventEdit_sPluginPrefix + s;
    }

    function ScrollTo(sID) {
        try {
            if (!CaseEventEdit_fBulkEdit) {
                $(window).scrollTop($('#' + sID).position().top);
            }
            else {
                $('#' + sID).parents('.itemBody').scrollTop($('#' + sID).position().top);
            }
        }
        catch (e) {
        }
    }
    function FixImages() {
        try {
            shrinkImagesToFit();
        }
        catch (e) {
        }
    }

    function ParseData(sResponse) {
        var o = $(sResponse);
        if ($.browser.msie) {
            return o.attr('sData'); //IE is happy to read the attributes, but won't read .text() or xml.
        }
        return o.text(); //FF/Chrome are happy to read xml or preserve spaces via .text(), but won't respect spaces in attributes.
    }

    function GetFormat(sResponse) {
        var o = $(sResponse);
        return o.attr("sFormat");
    }

    //Editor Constructor
    function ConstructEditor() {

        //Public members:
        var members = {
            MakeEditable: MakeEditable,
            EditCaseEvent: EditCaseEvent,
            GetInsertionPoint: GetInsertionPoint
        };

        //Private members:

        var sSAVING = 'Saving...';
        var hashForceRefresh = {};
        var hashAttach = {}; //dictionary of bugevent : { sFileName : ixFile }
        var hashFileToAttach = {}; //Dictionary of ixFile -> ixAttachment

        //Uploader class
        var Uploader = function() {
            var c = 0;
            var rgFxn = {};
            var cRgFxn = 0;

            return {
                UploadStart: function() { c++; },
                UploadComplete: function() {
                    c--;
                    if (c === 0) {
                        for (var ix = 0; ix < cRgFxn; ix++) {
                            rgFxn[ix]();
                        }
                        cRgFxn = 0;
                        rgFxn = {};
                    }
                },
                OnNotUploading: function(fxn) {
                    if (c === 0) {
                        fxn(); //If all uploads are complete, callback immediately.
                    }
                    else {
                        rgFxn[cRgFxn++] = fxn; //else, enqueue
                    }
                }
            };

        } ();

        //Function with private variable
        var GetUID = function() {
            var cUID = 1; // Start at 1, since 0 == false, which can suck.    
            return function() { return cUID++; };
        } ();

        function updateHashBEToEdit() {
            $(".caseEventEditIxEditData").each(function() {
                var me = $(this);
                var ixBE = me.data("ixbugevent");
                var ixEdit = me.data("ixedit");
                if (hashBEToEdit[ixBE] === undefined) {
                    hashBEToEdit[ixBE] = ixEdit;
                }
                else {
                    hashBEToEdit[ixBE] = Math.max(hashBEToEdit[ixBE], ixEdit);
                }
            });
        }

        $(function() { updateHashBEToEdit(); });

        function MakeEditable(ixBugEvent) {
            //This function will apply markup to a bugevent body so that it becomes editable.

            var body = $('#bugeventBody_' + ixBugEvent);

            //Place an empty span before the body text which we can use as an insertion point.
            body.before('<span id="CaseEventEditInsertionPoint' + ixBugEvent + '"></span>');

            //Initialize its attachment hash.
            hashAttach[ixBugEvent] = {};
        }

        function SetAttachmentButtonText(ixBugEvent, sText) {
            $('#BugEventAttachText' + ixBugEvent).text(sText);
        }

        function RemoveFile(ixFile, ixBugEvent) {
            var divFile = $('#CaseEventEdit_File' + ixFile);
            var sFile = divFile.attr('value');

            var cRemaining = $('#BugEventAttach' + ixBugEvent).children().length;

            divFile.stop().hide('blind', {}, 100, function() { $(this).remove(); });
            hashAttach[ixBugEvent][sFile] = undefined;

            if (cRemaining === 1) {
                //If we just removed the last attachment, revert our attachment text.
                SetAttachmentButtonText(ixBugEvent, 'Attach a file');
            }
        }

        function AddAttachment(ixBugEvent, sFile) {

            var spanAttach = $('#BugEventAttach' + ixBugEvent);
            if (sFile != '') {
                if (hashAttach[ixBugEvent] !== undefined && hashAttach[ixBugEvent][sFile] !== undefined) {
                    //We already have this file.
                    $('#CaseEventEdit_File' + hashAttach[ixBugEvent][sFile]).stop(true, true).effect('highlight', {}, 2000);
                    return false;
                }

                var ixFile = GetUID();

                var aRemove = $('<a href="javascript: void 0;">' + CaseEventEdit_sHTMLIconTrash + '</a>');
                aRemove.click(function() { RemoveFile(ixFile, ixBugEvent); });

                var divFile = $('<div style="margin-top:0.8em; padding-right:0.4em;" value="' + sFile + '" id="CaseEventEdit_File' + ixFile + '"><span id="CaseEventEdit_FileLoading' + ixFile + '">' + CaseEventEdit_sHTMLIconLoading + '</span>' + sFile + ' </div>');
                divFile.append(aRemove);

                spanAttach.append(divFile);

                SetAttachmentButtonText(ixBugEvent, 'Attach another file');

                if (hashAttach[ixBugEvent] === undefined) {
                    hashAttach[ixBugEvent] = {};
                }
                hashAttach[ixBugEvent][sFile] = ixFile;
                Uploader.UploadStart();
                return true;
            }
        }

        function SetEditSaving(ixBugEvent, fSaving) {
            if (fSaving) {
                $('#TextSaveEditEvent' + ixBugEvent).attr({ value: sSAVING, disabled: true });
                $('#TextCancelEditEvent' + ixBugEvent).attr({ disabled: true });
            }
            else {
                $('#TextSaveEditEvent' + ixBugEvent).attr({ value: 'OK', disabled: false });
                $('#TextCancelEditEvent' + ixBugEvent).attr({ disabled: false });
            }
        }
        function IsEditSaving(ixBugEvent) {
            return ($('#TextSaveEditEvent' + ixBugEvent).attr('value') == sSAVING);
        }
        function GetInsertionPoint(ixBugEvent) {
            var ip = $('#CaseEventEditInsertionPoint' + ixBugEvent);
            if (ip.length == 0) {
                MakeEditable(ixBugEvent);
                ip = $('#CaseEventEditInsertionPoint' + ixBugEvent);
            }
            return ip;
        }

        function DisableEditor(ixBugEvent) {
            $('#BugEventTextArea' + ixBugEvent).richtextarea({ enabled: false });
        }

        /****************************
        *  Editing Ajaxy functions: *
        ****************************/

        function EditCaseEvent(ixBugEvent) {
            if (CaseEventEdit_fBulkEdit) {
                $('#CaseEventEditIcon' + ixBugEvent).after('<div class="errorLabel">Cannot edit events while Bulk Editing cases</div>').remove();
                return;
            }

            var oInsertionPoint = GetInsertionPoint(ixBugEvent);
            if (oInsertionPoint.attr('editing') == 'true') {
                return;
            }

            //Mark us as editing.
            oInsertionPoint.attr('editing', 'true');
            //Hide the 'edit' icon and show the throbber.
            var icons = $('#CaseEventEditIcon' + ixBugEvent).children();
            $(icons[0]).hide();
            $(icons[1]).show();

            var fxn = function(sHTML, status) {
                var sData = ParseData(sHTML);
                var sErr = '';
                var fOK = $(sHTML).attr('fOK') == 1;
                if (!fOK) {
                    //Couldn't load the case.
                    sData = ''; //Don't say 'undefined'.
                    sErr = $(sHTML).attr('sMsg');
                    if (!sErr) { sErr = sREQUESTFAIL; }
                }

                var sPaddingButNotInIE = $.browser.msie ? '' : 'style = "padding-right:0.4em;"';
                var sAttachmentButton = '<div ' + sPaddingButNotInIE + '>';
                sAttachmentButton += '    <span style="padding:2px 0px 2px 2px;" id="BugEventAttachButton' + ixBugEvent + '">';
                sAttachmentButton += '        <a class="dotted" href="javascript: void 0;" id="BugEventAttachText' + ixBugEvent + '">';
                sAttachmentButton += '            Attach a file';
                sAttachmentButton += '        </a>';
                sAttachmentButton += '        <span style="padding-left:4px;" href="javascript: void 0;">';
                sAttachmentButton += '            ' + CaseEventEdit_sHTMLIconAttach;
                sAttachmentButton += '        </span>';
                sAttachmentButton += '    </span>';
                sAttachmentButton += '</div>';

                var dialog = '<div id="BugEventTextNew' + ixBugEvent + '" class="body editable">';
                dialog += '    <div><div class="summary" style="padding:6px 8px; border-bottom:#ccc 1px solid; background-color:#fffbee;" ><div class="action">Edit Case Event</div><span id="BugEventTextError' + ixBugEvent + '" class="errorLabel">' + sErr + '</span></div></div>';
                dialog += '    <div class="wideTextareaWrapper" style="margin: 0px;"><textarea id="BugEventTextArea' + ixBugEvent + '" class="bug" style="resize:none; width: 100%; border: 0px; padding: 2px;" onkeyup="adjustRows(this);" rows="8" cols="85" wrap="virtual" ></textarea></div>';
                dialog += '    <div class="footer">';
                dialog += '        ' + (fOK ? '<input class="actionButton2 dlgButton" id="TextSaveEditEvent' + ixBugEvent + '" type="submit" value="OK"/>' : '') + '';
                dialog += '        <input class="actionButton2 dlgButton" id="TextCancelEditEvent' + ixBugEvent + '"  type="button" value="Cancel"/>';
                dialog += '        <div style="text-align:right; margin-top:0.4em;">';
                dialog += '            ' + sAttachmentButton + '';
                dialog += '            <div id="BugEventAttach' + ixBugEvent + '" />';
                dialog += '        </div>';
                dialog += '    <div class="fixAlignment"></div>';
                dialog += '    </div>';
                dialog += '</div>';

                $(dialog).hide().insertAfter(oInsertionPoint).children('#BugEventTextArea' + ixBugEvent);

                //Set the textarea's data. We have to do this after the preceeding DOM insertion, else it mysteriously fails.
                var textarea = $('#BugEventTextArea' + ixBugEvent);
                textarea.val(sData);

                //Enable snippets for this textarea (Only allowed in FB8+)
                textarea.keypress(function(evt) {
                    fb.snippet.handleSnippetTargetKeypress(this, evt)
                });

                var fHtml = (GetFormat(sHTML) === "html");
                // Hook up the editor used by FogBugz to edit case events
                textarea.richtextarea({
                    config: {
                        FBformsubmit_targetSelector: "#TextSaveEditEvent" + ixBugEvent
                    },
                    enabled: fHtml,
                    containsHtml: fHtml
                });

                //Show
                $('#BugEventTextNew' + ixBugEvent).slideDown(200, function() { // use slideDown instead of blind because of FF/Chrome graphical glitchs.
                    //Now that we've finished loading it, disable the 'loading' graphic and hide the edit icon.
                    var icons = $('#CaseEventEditIcon' + ixBugEvent).children();
                    $(icons[0]).show();
                    $(icons[1]).hide();
                    $('#CaseEventEditIcon' + ixBugEvent).hide();
                });

                //Activate buttons:
                $('#TextSaveEditEvent' + ixBugEvent).click(function() { EditSave(ixBugEvent); return false; });
                $('#TextCancelEditEvent' + ixBugEvent).click(function() { EditStop(ixBugEvent); return false; });

                var sURLUploadFile = CaseEventEdit_sRawPageURL + Prefix('action=uploadFile');
                new AjaxUpload('BugEventAttachButton' + ixBugEvent, {
                    hoverClass: 'CaseEventEditUploadHover',
                    action: sURLUploadFile,
                    name: CaseEventEdit_sPluginPrefix + 'sFile',
                    autoSubmit: true,
                    responseType: false,
                    onChange: function(sFile, extension) { return AddAttachment(ixBugEvent, sFile); },
                    onSubmit: function(file, extension) { },
                    onComplete: function(sFile, response) {
                        if ($(response).attr('fOK')) {
                            hashFileToAttach[hashAttach[ixBugEvent][sFile]] = ParseData(response);
                        }
                        else {
                            var sErr = $(response).attr("sMsg");
                            if (sErr === undefined) {
                                sErr = "The server failed to receive the file- Perhaps the attachment is too large?";
                            }
                            $('#BugEventTextError' + ixBugEvent).html("There was a problem uploading " + sFile + ":<br/>" + sErr).effect('highlight', {}, 2000);
                            RemoveFile(hashAttach[ixBugEvent][sFile], ixBugEvent);
                        }
                        Uploader.UploadComplete();
                        $('#CaseEventEdit_FileLoading' + hashAttach[ixBugEvent][sFile]).fadeOut('slow', function() { $(this).remove(); });
                    }
                });

            };

            var sURL = CaseEventEdit_sRawPageURL;
            var ixEdit = hashBEToEdit[ixBugEvent];
            if (ixEdit === undefined) {
                ixEdit = -1;
            }

            sURL += Prefix('action=getEditS');
            sURL += Prefix('ixBugEvent=' + encodeURIComponent(ixBugEvent));
            sURL += Prefix('ixEdit=' + encodeURIComponent(ixEdit));

            jQuery.get(sURL, fxn);
        }

        function EditSave(ixBugEvent) {
            //If already saving, back off.
            if (IsEditSaving(ixBugEvent)) {
                return;
            }
            //Mark that we're working
            SetEditSaving(ixBugEvent, true);

            var textAreaNew = $('#BugEventTextArea' + ixBugEvent);
            var textAreaNewFormat = $('#BugEventTextArea' + ixBugEvent + "_sFormat");

            //If save is a failure, notice it.
            var fxnFail = function(ixEditLatest, sErr, status) {

                if (sErr == 'Nothing Changed') {
                    //Tried to save something which was the same as the current version.
                    //Although effectively a 'cancel', we want to do a force refresh so as to have consistent side-effects. (like, say, with history.)
                    hashForceRefresh[ixBugEvent] = true;
                    EditStop(ixBugEvent);
                    return;
                }
                if (sErr == 'Newer') {
                    //The case has been edited since we last viewed it.

                    //Show the diff between our current and the latest version,
                    Historian.ShowHistory(ixBugEvent, ixEditLatest, hashBEToEdit[ixBugEvent]);
                    //Display warning text explaining what's going on,
                    $('#BugEventTextError' + ixBugEvent).text("The changes above were submitted while you were editing. They will be overwritten unless you incorporate them into your own changes.").stop(true, true).effect('highlight', {}, 2000);
                    //Mark a force refresh (So that we get the latest bugevent if we cancel the edit.)
                    hashForceRefresh[ixBugEvent] = true;
                    //Take note not to bounce again
                    hashBEToEdit[ixBugEvent] = ixEditLatest;
                    //Continue editing
                    SetEditSaving(ixBugEvent, false);
                    return;
                }

                if (!sErr) {
                    sErr = sREQUESTFAIL;
                }
                $('#BugEventTextError' + ixBugEvent).text("Unable to save edit: " + sErr);
            };

            //If save is successful, refresh the bugevent edited and add the new one.
            var fxnOK = function(ixBugEventCreated) {
                var fxn = function(sData, status) {
                    if ($(sData).attr('fOK') != 1) {
                        EditStop(ixBugEvent);
                        $('#bugeventBody_' + ixBugEvent).html('<em>Although the edit was saved successfully, Case Event Edit had a problem displaying the changes. The latest text will be available if you <strong>refresh this page</strong>.  If this message appears with any frequency, please report the issue to Fog Creek Software.<br/><br/>Error message:[' + $(sData).attr('sMsg') + ']<br/>AjaxStatus:[' + status + ']</em>');
                        return;
                    }
                    // Get rid of the rich textarea
                    DisableEditor(ixBugEvent)

                    //Rerender the updated bugevent.
                    //This will set hashBEToEdit[ixBugEvent] for us.
                    var j = $('#bugeventBody_' + ixBugEvent).parent('.bugevent').after($(sData).attr('sData0'));
                    updateHashBEToEdit();
                    j.remove();
                    $('#bugeventBody_' + ixBugEvent).effect('highlight', {}, 2000);

                    //Insert the new bugevent.
                    var sRenderLatest = $(sData).attr('sData1');
                    //Test for' fMostRecentEventFirst == 1' explicitally, since we don't know the 'false' value.
                    var insert = fMostRecentEventFirst == 1 ? $('#newBugEventInsertBelowPoint') : $('#newBugEventInsertAbovePoint');
                    //If insert has no children, create one.  Else, add to the existing set.
                    if (insert.children().length == 0) {
                        insert.append(sRenderLatest);

                    }
                    else {
                        if (fMostRecentEventFirst == 1) {
                            insert.children(':first').before(sRenderLatest);
                        }
                        else {
                            insert.children(':last').after(sRenderLatest);
                        }
                    }
                    CaseEventEdit.FixImages();

                    //If we're still viewing the latest ixBugEvent (with no gaps), disable the warning scripts:
                    if ($(sData).attr('sData2') == 1) {
                        ixBugEventLatest = ixBugEventCreated;
                        $('input[name="ixBugEventLatest"]').val(ixBugEventLatest);
                    }

                    //If we were forcing a refresh... stop.  We just did.
                    hashForceRefresh[ixBugEvent] = false;
                };
                var sURL = CaseEventEdit_sRawPageURL;
                sURL += Prefix('action=minimalUpdates');
                sURL += Prefix('ixBugEventThoughtLatest=' + encodeURIComponent(ixBugEventLatest));
                sURL += Prefix('ixBugEventEdited=' + encodeURIComponent(ixBugEvent));
                sURL += Prefix('ixBugEventCreated=' + encodeURIComponent(ixBugEventCreated));
                jQuery.get(sURL, fxn);
            };

            //I'm a continuation!
            var continuation = function() {

                var sRgIxAttachment = '';
                for (var sFile in hashAttach[ixBugEvent]) {
                    var ixAttachment = hashFileToAttach[hashAttach[ixBugEvent][sFile]];
                    if (ixAttachment !== undefined) {

                        if (sRgIxAttachment !== '') {
                            sRgIxAttachment += ',';
                        }
                        sRgIxAttachment += ixAttachment;
                    }
                }

                ajaxEditSave(textAreaNew.val(), textAreaNewFormat.val() || '', sRgIxAttachment, ixBugEvent, fxnOK, fxnFail);
            };
            //If there are files uploading, wait for them.

            Uploader.OnNotUploading(continuation);


        }

        function ajaxEditSave(s, sFormat, sRgIxAttachment, ixBugEvent, fxnOK, fxnFail) {
            var fxn = function(sAJAX, status) {
                var fxnArg = function(s) { return $(sAJAX).attr(s); };

                if (fxnArg('fOK') == 1) {
                    fxnOK(fxnArg('sData1'));
                }
                else {
                    fxnFail(fxnArg('sData0'), fxnArg('sMsg'), status);
                }
            };
            var ixEditCurrent = hashBEToEdit[ixBugEvent];
            if (ixEditCurrent === undefined) {
                ixEditCurrent = -1;
            }

            var sData = Prefix('action=save');
            sData += Prefix('s=' + encodeURIComponent(s));
            sData += Prefix('sFormat=' + encodeURIComponent(sFormat));
            sData += Prefix('sRgIxAttachment=' + encodeURI(sRgIxAttachment));
            sData += Prefix('ixBugEvent=' + encodeURIComponent(ixBugEvent));
            sData += Prefix('ixEditCurrent=' + encodeURIComponent(ixEditCurrent));
            sData += Prefix('actionToken=' + CaseEventEdit_sActionToken);
            $.ajax({ type: "POST",
                url: CaseEventEdit_sRawPageURL,
                success: fxn,
                data: sData
            });
        }

        function EditStop(ixBugEvent) {
            //Display the normal bugevent view:
            if (hashForceRefresh[ixBugEvent]) {
                //Re-render
                hashForceRefresh[ixBugEvent] = false; //Only try once.

                var fxn = function(sData, status) {
                    if ($(sData).attr('fOK') != 1) {
                        //If failure, don't bother with a rendering- just restore the old stuff.
                        //This acts like a 'cancel'...  History will remain open, and the edit box will slide closed.
                        EditStop(ixBugEvent);
                        return;
                    }

                    // Get rid of the rich textarea
                    DisableEditor(ixBugEvent)

                    //The rendering will set hashBEToEdit[ixBugEvent] and hashAttach for us.
                    $('#bugeventBody_' + ixBugEvent).parent('.bugevent').after(ParseData(sData)).remove();
                    $('#bugeventBody_' + ixBugEvent).effect('highlight', {}, 2000);
                    CaseEventEdit.FixImages();

                };
                var sURL = CaseEventEdit_sRawPageURL;
                sURL += Prefix('action=renderBugEvent');
                sURL += Prefix('ixBugEvent=' + encodeURIComponent(ixBugEvent));
                jQuery.get(sURL, fxn);
            }
            else {
                //Remove the editing dialog:
                DisableEditor(ixBugEvent);
                $('#BugEventTextNew' + ixBugEvent).hide('blind', {}, 200, function() {
                    $(this).remove();
                });

                //Just make the old rendering visible again
                var insertion = GetInsertionPoint(ixBugEvent);
                insertion.attr('editing', 'false');
                $('#CaseEventEditIcon' + ixBugEvent).show();

                //Blank the attachments queue:
                hashAttach[ixBugEvent] = undefined;
            }
        }

        return members;
    }

    //Historian constructor
    function ConstructHistorian() {

        //Public Members:
        var members = {
            ToggleHistory: ToggleHistory,
            ShowHistory: ShowOrRefreshHistory,
            HideHistory: HideHistory,
            RefreshHistoryFromSelectObj: RefreshHistoryFromSelectObj
        };

        //Private members:

        function SetHistoryLoading(ixBugEvent, fLoading) {
            var jLoading = $('#EventHistory' + ixBugEvent);
            if (fLoading) {
                jLoading.text('[Loading]');
            }
            else {
                jLoading.html(jLoading.attr('value'));
            }
        }

        function DLCLHistory(ixBugEvent) {
            DropListControl.refreshWithin($('#CaseEventEditHistory' + ixBugEvent));
        }

        var FlashHistory = function(ixBugEvent) {
            $('#CaseEventEditHistory' + ixBugEvent).stop(true, true).effect('highlight', {}, 2000);
        };

        function HideHistory(ixBugEvent) {
            $("#CaseEventEditHistory" + ixBugEvent).stop(true).effect('blind', {}, 'fast', function() {
                $(this).remove();
                $("#EventHistory" + ixBugEvent).attr('fShowing', 0);
            });
        }

        /****************************
        *  History Ajaxy functions: *
        ****************************/

        function ShowOrRefreshHistory(ixBugEvent, ixEditNew, ixEditOld) {
            if ($('#EventHistory' + ixBugEvent).attr('fShowing') == 1) {
                //refresh
                if (ixEditOld === undefined) {
                    ixEditOld = -1;
                }
                RefreshHistory(ixBugEvent, ixEditNew, ixEditOld);
            }
            else {
                //show
                ToggleHistory(ixBugEvent, ixEditNew, ixEditOld, true);
            }
        }

        function CleanDataForIE(sData) {
            //IE8 MEGAHACK, (because white-space:pre-wrap is not respected, and whitespace is collapsed upon DOM insertion):
            //If not inside a <>, convert all spaces to &ensp;'s.
            if ($.browser.msie) {
                var sOut = '';
                var cLB = 0;
                for (var ixData = 0, lenData = sData.length; ixData < lenData; ixData++) {
                    var ch = sData.charAt(ixData);
                    if (ch == '<') {
                        cLB++;
                    }
                    else if (ch == '>' && cLB > 0) {
                        cLB--;
                    }
                    else if (ch === ' ') {
                        if (cLB === 0) {
                            ch = "&ensp;"
                        }
                    }

                    sOut += ch;
                }
                return sOut;
            }
            return sData;
        }

        function ToggleHistory(ixBugEvent, ixEditNew, ixEditOld, fFlash) {

            //Until the history is fixed for Safari, give an error rather than puking.        	
            if (window.safari) {
                $('#EventHistory' + ixBugEvent).html('<strong>[Unavailable in Safari]</strong>').stop(true, true).effect('highlight', {}, 5000);
                return;
            }

            //If already exists, hide
            if ($('#EventHistory' + ixBugEvent).attr('fShowing') == 1) {
                HideHistory(ixBugEvent);
                return;
            }
            $("#EventHistory" + ixBugEvent).attr('fShowing', 1);

            //Mark us as loading:
            SetHistoryLoading(ixBugEvent, true);


            //Get diff:
            var fxn = function(sAJAX, status) {
                var sData;
                if ($(sAJAX).attr('fOK') == 1) {
                    sData = ParseData(sAJAX);
                }
                else {
                    sData = $(sAJAX).attr('sMsg');
                    if (!sData) { sData = sREQUESTFAIL; }
                }

                //Create and show the history:
                var sHistory = '<div id="CaseEventEditHistory' + ixBugEvent + '" style="display:none; margin:5px 0 10px; border:#ccc 1px solid;"></div>';
                Editor.GetInsertionPoint(ixBugEvent).before(sHistory);
                $('#CaseEventEditHistory' + ixBugEvent).html(CleanDataForIE(sData)).slideDown('fast'); // use slideDown instead of blind because of an IE8 graphical glitch.
                DLCLHistory(ixBugEvent);

                //Remove the 'loading' notification.
                SetHistoryLoading(ixBugEvent, false);
                if (fFlash) {
                    FlashHistory(ixBugEvent);
                }

            };

            if (ixEditNew === undefined) {
                ixEditNew = hashBEToEdit[ixBugEvent];
                //if ixEditNew is still undefined at this point, ajaxGetDiff is going to fail.
                //If a history view is visible, however, it should not be undefined unless we're in Bulk Edit mode.
                if (CaseEventEdit_fBulkEdit && ixEditNew === undefined) {
                    ixEditNew = -1;
                }
            }
            if (ixEditOld === undefined) {
                ixEditOld = -1;
            }
            ajaxGetDiff(ixBugEvent, ixEditNew, ixEditOld, fxn);
        }

        function RefreshHistoryFromSelectObj(objSelect) {
            //Yield momentarily so that the javascript from the dropdowns doesn't step on us.
            //If it manages to anyway, the 'loading' text is obscured- no biggie.
            setTimeout(function() {

                var ixBugEvent, ixEditOld, ixEditNew;

                //Extract the params from the Option:
                //They look like this:  "[ixBugEvent,ixEditOld,ixEditNew]"
                var rgArgs = null;
                $(objSelect).children().each(function() {
                    if ($(this).attr('selected')) {
                        var re = /\[[0-9]+,[0-9]+,[0-9]+\]/;
                        if (re.test($(this).val())) {
                            rgArgs = eval($(this).val()); //Using 'eval' as my JSON parser.

                            //loading notifier.
                            var rg = [$('#idDropList_selectNew' + rgArgs[0] + '_oText'), $('#idDropList_selectOld' + rgArgs[0] + '_oText')];
                            rg[0].val('Loading...');
                            rg[1].val('Loading...');
                        }
                    }
                });
                if (rgArgs === null) {
                    return;
                }

                ixBugEvent = rgArgs[0];
                ixEditOld = rgArgs[1];
                ixEditNew = rgArgs[2];

                ajaxPerformRefresh(ixBugEvent, ixEditNew, ixEditOld, function() { });

            }, 10);
        }

        function ajaxPerformRefresh(ixBugEvent, ixEditNew, ixEditOld, fxnFinally) {

            //Get diff:
            var fxn = function(sAJAX, status) {
                var sData;
                if ($(sAJAX).attr('fOK') == 1) {
                    sData = ParseData(sAJAX);
                }
                else {
                    sData = $(sAJAX).attr('sMsg');
                    if (!sData) { sData = sREQUESTFAIL; }
                }

                //Update the history:
                $('#CaseEventEditHistory' + ixBugEvent).html(CleanDataForIE(sData));
                DLCLHistory(ixBugEvent);
                fxnFinally();
            };
            ajaxGetDiff(ixBugEvent, ixEditNew, ixEditOld, fxn);
        }

        function RefreshHistory(ixBugEvent, ixEditNew, ixEditOld) {

            SetHistoryLoading(ixBugEvent, true);

            var fxnFinally = function() {
                SetHistoryLoading(ixBugEvent, false);
                //Flash!
                FlashHistory(ixBugEvent);
            };

            ajaxPerformRefresh(ixBugEvent, ixEditNew, ixEditOld, fxnFinally);
        }

        function ajaxGetDiff(ixBugEvent, ixEditNew, ixEditOld, fxn) {
            var sURL = CaseEventEdit_sRawPageURL;
            sURL += Prefix('action=diff');
            sURL += Prefix('ixBugEvent=' + encodeURIComponent(ixBugEvent));
            sURL += Prefix('ixEditNew=' + encodeURIComponent(ixEditNew));
            sURL += Prefix('ixEditOld=' + encodeURIComponent(ixEditOld));
            jQuery.get(sURL, fxn);
        }

        return members;
    }

    return members;
} ();
