Discuss Plus (Beta Release)
======================
This Plugin adds a widget that you can insert into a FogBugz wiki to display an article index. 

It is very similar to the Fog Creek "Wiki Page Table of Contents" plugin, except that it creates a table of contents listing all articles in the wiki, instead of a listing of headers within the same wiki article.

Requirements
============
FogBugz Version 8.4.87 or later.

Installation
===========
Use the upload plug-in button on the FogBugz plug-in page and select the WikiArticleIndex.zip file you downloaded from the plug-in gallery.

MPORTANT: You have to upload the entire zip file for the plug-in to work.
  
Functionality
=============
The insertable article index will display a  table of contents for the current wiki with a clickable link to each referenced article.

FAQ
===
Q: How is this different than the Fog Creek "Wiki Page Table of Contents" plug-in?
A: That plug-in builds a table of contents from the header styles within the single article it is inserted into. This plug-in provides a table of contents listing all of the articles in the wiki.

Q: Can I modify the look of the TOC that is displayed?
A: By editing the WikiArticleIndex.CSS file in the ZIP file before installing it, you can tweak the appearance to some degree. It is safe to re-install the plug-in repeatedly if you need to fine tune the CSS settings.

Q: How can I exclude a wiki article from inclusion in the Table of Contents?
A1: When inserting a new article index or from the edit menu on an already inserted widget, specify a title filter.
A2: Open the relevant article and press the "Info" button in the top right corner to configure it. Then Uncheck the "Include this article in indexes" checkbox under the "Wiki Article Index" section.

Q: My article is not showing up, even though "Include this article in indexes" is checked. What's up with that?
A: The table of contents is designed to never include the current page (the one with the index in it) in the index. 

Q: Can I include this plug-in on a wiki template page?
A: Not yet. I do, however, plan to support this in future versions.

Q: Will "Include only pages with links in this page" feature include wiki pages more than one level deep?
A: No. Sorry, this feature currently only filters for wiki pages directly linked within the current page (the one that the index is on). 
   
Release Notes
---------------------
** Version 1.7.0 **
Article index can now optionally include articles from Wikis other than the one it is inserted into.

** Version 1.6.0 **
Feature: New setting lets you optionally filter an index to articles that contain a given tag.

** Version 1.5.0 **
Feature: New setting allows you to optionally filter an index to only include articles that are linked in the current article (the one containing the index).
Fix: compatibility updates for FogBugz version 8.7.16 and later

** Version 1.4.2 **
Fix: Updated code to work with jQuery 1.6.X (used by FogBugz 8.5.88H and later)

** Version 1.4.1 **
Fix: No material change. Updated plug-in properties to reflect that 1.4.x releases only work in FB 8.4.87 and later. Previous version incorrectly reported that it was compatible with FB 7.3 and later.

** Version 1.4.0 **
Feature: Added the ability to filter what is included in the table of contents by the header with a starts with, ends with, or contains expression.

** Version 1.3.0 **
Feature: New setting when inserting an article index allows you to specify the sort type (Title/Modified Date) and order (Ascending/Descending)
Feature: New Setting allows you to include the last modified date next to the article listing in the article index.
Feature: You can now exclude articles you don't want included in the article index with a new setting on the article's "info" page.

** Version 1.2.0 **
Fix: New articles created by creating a link to them, but that haven't yet been written are no longer included in the TOC.

** Version 1.1.0 **
Fix: Fixed bug that caused article to throw query error when used against FogBugz installations using case sensitive database platforms.

** Version 1.0.0 **
Fix: TOC entries containing HTML were not being escaped properly.

** Version 0.9.0 Beta Release) **


Enjoy!

John Fuex 
john.fuex@gmail.com
http://improvingsoftware.com

