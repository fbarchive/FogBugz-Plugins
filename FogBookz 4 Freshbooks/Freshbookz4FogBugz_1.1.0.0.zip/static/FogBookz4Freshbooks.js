﻿var FogBookz4FreshbooksPlugin = new function () {
	var oSelf = this;
	var hashdata = {};

	this.doPopup = function (elPopupAnchor) {
		oSelf.Popup.setHtml(
	'<form id="FogBookzNotesEditPopup" onsubmit="return false;">' +
	'<div class="dialog dialog-double-col" style="width: 400px;">' +
		'<p id="FogBookzNotesTitle" class="dialog-title">Notes for Interval</p>' +
		'<table cellspacing="0" width="100%">' +
		'<tbody>' +
		'<tr class="dialog-item   "><th class="dialog-item-label dialog-double-col-cell" style="width: ">Notes:</th><td class="dialog-double-col-cell">' +
		'<div class="dialog-item-content">' +
		'<textarea maxlength="4000" rows="5" id="FogBookzNotes"></textarea></div></td></tr>' +
		'<tr class="dialog-item    dialog-item-last"><th class="dialog-item-label dialog-double-col-cell" style="width: "></th><td class="dialog-double-col-cell">' +
		'<div class="dialog-item-content">' +
		'<input type="submit" onclick="setNotes();FogBookz4FreshbooksPlugin.Popup.hide(); return false; " name="OK" class="dlgButton" value="OK" chotkey="o" id="id_0">' +
		'<input type="submit" onclick="FogBookz4FreshbooksPlugin.Popup.hide();return false; " name="OK" class="dlgButton" value="Cancel" chotkey="c" id="id_1">' +
		'</div></td></tr></tbody></table></div></form>');
		oSelf.Popup.showPopup(elPopupAnchor);
		return false;
	}

	this.ProjectAllSelected = function (projectId, myDDLTask, myDDLStaff) {

		// see if we already have the data stored
		if (GetDataForProject(projectId) != null) {
			var data = GetDataForProject(projectId);
			UpdateDropDown(data, myDDLTask, "Task");
			UpdateDropDown(data, myDDLStaff, "Staff");
		}
		else {
			// send the ajax request to update things on the server
			var sUrl = oSelf.PluginRawPageUrl + "&" +
			oSelf.PluginPrefix + "pre=" + oSelf.Request + "&" +
			oSelf.PluginPrefix + "ix=" + projectId;

			Info.show("Contacting Freshbooks...");
			DisableAllSelects();

			// request the tasks
			jQuery.post(sUrl, null, function (ajaxdata) {
				Info.hide();
				EnableAllSelects();
				if (ajaxdata != null && jQuery(ajaxdata).find('error').text() == "") {
					SetDataForProject(projectId, ajaxdata);
					UpdateDropDown(ajaxdata, myDDLTask, "Task");
					UpdateDropDown(ajaxdata, myDDLStaff, "Staff");
				}
				else {
					var ddl = jQuery('select[name="' + myDDLTask + '"]');
					// clear tasks
					ddl.get(0).options.length = 0;

					// add default
					ddl.get(0).options[0] = new Option("-- Failed to load --", "-1");
					DropListControl.refresh(ddl[0]);
					ddl = jQuery('select[name="' + myDDLStaff + '"]');
					// clear tasks
					ddl.get(0).options.length = 0;

					// add default
					ddl.get(0).options[0] = new Option("-- Failed to load --", "-1");
					DropListControl.refresh(ddl[0]);
				}
			});
		}

		jQuery('select[name*="project_"]').each(function () {
			jQuery(this).val(projectId);
			DropListControl.refresh(jQuery(this)[0]);
			jQuery(this).change();
		});

	}
	this.TaskAllSelected = function (taskId) {
		jQuery('select[name*="task_"]').each(function () {
			jQuery(this).val(taskId);
			DropListControl.refresh(jQuery(this)[0]);
		});
	}
	this.StaffAllSelected = function (staffId) {
		jQuery('select[name*="staff_"]').each(function () {
			jQuery(this).val(staffId);
			DropListControl.refresh(jQuery(this)[0]);
		});
	}


	this.ProjectSelected = function (projectId, taskDDLname, staffDDLname) {

		// send the ajax request to update things on the server
		var sUrl = oSelf.PluginRawPageUrl + "&" +
			oSelf.PluginPrefix + "pre=" + oSelf.Request + "&" +
			oSelf.PluginPrefix + "ix=" + projectId;

		// see if we already have the data stored
		if (GetDataForProject(projectId) != null) {
			var data = GetDataForProject(projectId);
			UpdateDropDown(data, taskDDLname, "Task");
			UpdateDropDown(data, staffDDLname, "Staff");
		}
		else {
			Info.show("Contacting Freshbooks...");
			DisableAllSelects();
			// request the tasks
			jQuery.post(sUrl, null, function (ajaxdata) {
				Info.hide();
				EnableAllSelects();
				if (ajaxdata != null && jQuery(ajaxdata).find('error').text() == "") {
					SetDataForProject(projectId, ajaxdata);
					UpdateDropDown(ajaxdata, taskDDLname, "Task");
					UpdateDropDown(ajaxdata, staffDDLname, "Staff");
				}
				else {
					var ddl = jQuery('select[name="' + taskDDLname + '"]');
					// clear tasks
					ddl.get(0).options.length = 0;

					// add default
					ddl.get(0).options[0] = new Option("-- Failed to load --", "-1");
					DropListControl.refresh(ddl[0]);
					ddl = jQuery('select[name="' + staffDDLname + '"]');
					// clear tasks
					ddl.get(0).options.length = 0;

					// add default
					ddl.get(0).options[0] = new Option("-- Failed to load --", "-1");
					DropListControl.refresh(ddl[0]);
				}
			});
		}
	}

	function DisableAllSelects() {
		jQuery('select').each(function () {
			jQuery(this).attr('disabled', 'disabled');
			DropListControl.refresh(jQuery(this)[0]);
		});
	}

	function EnableAllSelects() {
		jQuery('select').each(function () {
			jQuery(this).attr('disabled', false);
			DropListControl.refresh(jQuery(this)[0]);
		});
	}

	function GetDataForProject(projectIx) {
		if (typeof hashdata[projectIx] !== 'undefined' && hashdata[projectIx] !== null) {
			return hashdata[projectIx];
		}

		return null;
	}

	function SetDataForProject(projectIx, xmldata) {
		hashdata[projectIx] = xmldata;
	}


	function UpdateDropDown(jXML, DDLname, root) {

		var taskList = jQuery(root, jXML);

		// see if we can find our div
		var ddl = jQuery('select[name="' + DDLname + '"]');
		if (ddl == null || ddl.length == 0) {
			return false;
		}
		else {
			// clear
			ddl.get(0).options.length = 0;

			jQuery("item", taskList).each(function () {
				var display = jQuery(this).find('display').text();
				var value = jQuery(this).find('value').text();

				ddl.get(0).options[ddl.get(0).options.length] = new Option(display, value);

			});
			DropListControl.refresh(ddl[0]);
		}

	}

	$(document).ready(function () {
		oSelf.Popup = api.PopupManager.newPopup("FogBookz4FreshbooksPluginDialog");
		hashdata[""] = "<Freshbooks><Task><item><display>-- Select Project First --</display><value></value></item></Task><Staff><item><display>-- Select Project First --</display><value></value></item></Staff></Freshbooks>"
	});
} ();


