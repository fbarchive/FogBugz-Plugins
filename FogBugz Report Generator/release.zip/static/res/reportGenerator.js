var edited = false;

function isOkToSave() {
//alert('edited: ' + edited);
    if (edited) {
        return confirm('Updating the report range will override your unsaved changes. Are you sure you want to update without saving first?');
    }
    return true;
}

/* Edit the content of a TextSection.
 * editLink is the link that the user clicked. The link is in a specific position relative to the other elements that need to be read/modified for this specific section
 */
function editContent(editLink){
    //Get the current content div of the TextSection
    var stubText = $(editLink).prev();
    
    /*We have to do this weird thing with resetting the html of the stubText and then getting the text
    * because every more obvious way to get the text resulted in weird newline or other formatting errors */
    var html = stubText.html();
    stubText.html(html.replace(/<br>/gm,'\n')); //Turn the <br>'s into newlines, or else the <br>'s will just be discarded without newlines in their place
    var text = stubText.text();
    
     //Show the text editing area
    var stubTextContainer = $(editLink).parent().nextAll('.stubTextContainer');
    stubTextContainer.show();
    
    //set <textarea>'s text to the current section text and select it all.
    var stubTextArea = stubTextContainer.find('.stubTextArea');
    stubTextArea.val(text).focus().select();
    
    //Hide the div displaying the section text while the user is editing the text
    $(editLink).parent().hide();
}

/* Save the content of a TextSection.
 * saveLink is the link that the user clicked. The link is in a specific position relative to the other elements that need to be read/modified for this specific section
 */
function saveStub(saveLink){
    //Initialize JQuery objects
    var stubTextContainer = $(saveLink).parent();
    var stubTextArea = $(saveLink).prevAll('.stubTextArea');
    var stubText = stubTextContainer.prev().find('.stubText');

    //Get the new content for the TextSection
    var text = stubTextArea.val();

    /*We have to do this weird thing with setting the text of the stubText and then resetting the html
    * because every more obvious way to get the text resulted in weird newline or other formatting errors */
    stubText.text(text);
    var html = stubText.html();
    stubText.html(html.replace(/\n/gm,'<br>')); //The newlines are still in the html, so turn them into <br> tags so we can see what the report really looks like
    
    //Hide the text editing area and show the text display area
    closeStubEdit(stubTextContainer);
    edited = true;
}

/* Cancel the changes to the TextSection's text. Reset the text back to it's value before the user clicked the edit link
 * cancelLink is the link that the user clicked. The link is in a specific position relative to the other elements that need to be read/modified for this specific section
 */
function cancelStub(cancelLink){
    var stubTextContainer = $(cancelLink).parent();
    closeStubEdit(stubTextContainer);
}

/* Hide the text editing area and show the text display area based on a text editing area's div
 * stubTextContainer is the div holding the text editing area
 */
function closeStubEdit(stubTextContainer){
    stubTextContainer.hide(); //Hide text editing area
    stubTextContainer.prev().show(); //Show text display area
}

/* Hide or show the content of a section based on if the 'Show Section' checkbox is checked
 * checkbox is the checkbox element that determines whether a specific section should be shown or not
 */
function toggleSection(checkbox){
    edited = true;
    var content = $(checkbox).parent().find('div.sectionContent:first');
    if(checkbox.checked){
        content.show();
    }else{
        content.hide();
    }
}

/* Updates the different report sections in the stub preview with updated data.
 * This function is called after loading new preview data from the server when updating report options for example
 * newSections is a string of HTML containing the new report data and content. It is in the following format:
 * #reportUpdate
 * |-#reportHeader (The title of the report; what will become the wiki header)
 * |-#reportDate (The end date of the report formatted as text)
 * |-#teamMembers (The list of teamMembers included in the report)
 * | |-.teamMember (The name of a team member [This <span> is repeated for each team member])
 * |-#<section_path>.sectionUpdate (A <div> containing the new HTML to set as the HTML for the section given by the section_path in the id attribute)
 */
function updateSections(newSections){
//    alert(newSections);

    //Set the report header
    var reportHeader = $(newSections).find('h1.reportHeader').html();
    $(document).find('h1.reportHeader').html(reportHeader);

    //Set the team member list
 /*
    var reportTeamMembers = $(newSections).find('#reportTeamMembers').html();
    $('h3.reportTeamMembers').html(reportTeamMembers);

    //Set the report date displayed
    var reportDate = $(newSections).find('#reportDate').html();
    $('h3.reportDate').html(reportDate);

    //Copy the sectionUpdate HTML to the appropriate sections
    var newSectionDivs = $(newSections).find('div.sectionUpdate');
    newSectionDivs.each(function(){
      var path = this.id;
      //alert(path);
      var sectionContent = $('input.path[value=""' + path + '""]').nextAll('div.sectionContent'); //Get the sectionContent of the section from the path
      //sectionContent.remove();
      sectionContent.children(':not(div.section)').remove(); //Remove the sectionContent except for the subSections
      sectionContent.prepend($(this).html()); //Add the new section content as the first elements of the sectionContent <div>
    });
 */
  
    var repBod = $(newSections).find('#reportBody').html();
//    alert(repBod);
    $(document).find('#reportBody').html(repBod);

    //Hide all of the TextSection edit boxes
    $('.stubTextContainer').hide();

/*    var sectVis = $(newSections).find('#sectionVisibilities').html();
    //alert(sectVis);
    updateVisibility(sectVis);
*/

    var sectDT = $(newSections).find('#dateTimeUpdate').html();
    updateDateTime(sectDT);

    //Hide the loading indicator
    ajaxDone();
    edited = false;
}

function updateVisibility(sectVis) {
    var sects = sectVis.split(';');
    for(var i=0; i < sects.length; i++) {
        var vis = sects[i];
        var vispart = vis.split(':');
        if(vis.length > 1) { //Make sure both section name and visibility are there, else skip it
            var elem = vispart[0].split(' ').join('')
            if(elem.length > 0) {
                var cb = document.getElementById(elem);
                if(cb != null) { //Skip Sections with no Check Box
                    cb.checked=(vispart[1].toLowerCase() == 'true');
                    toggleSection(cb);
                }
            }
        }
        
        //alert(vis);
    }
}

function updateDateTime(sectVis) {
    var sects = sectVis.split(';');
    for(var i=0; i < sects.length; i++) {
        var vis = sects[i];
        var vispart = vis.split('|');
        if(vis.length > 1) { //Make sure both section name and value are there, else skip it
            //alert(vispart[0] + ' | ' + vispart[1]);
            if(vispart[0] == 'startDate') {
                $('#startDate').val(vispart[1]);
            } else if (vispart[0] == 'startTime') {
                $('#startTime').val(vispart[1]);
            } else if(vispart[0] == 'endDate') {
                $('#endDate').val(vispart[1]);
            } else if(vispart[0] == 'endTime') {
                $('#endTime').val(vispart[1]);
            }
        }
    }
}

//Timer to update the ajax I/O indicator
var ajaxTimer = null;

//Called when an AJAX operation is completed.
function ajaxDone(){
    //Stop the I/O indicator timer and hide the indicator
    clearInterval(ajaxTimer);
    ajaxTimer = null;
    $('.ajaxIndicator').hide();
    
    //Allow the report to be submited now that the operation is completed
    $('.ajaxSubmit').attr('disabled',false);
}

/* While an ajax operation is in progress, update the I/O indicator animation to cycle through dots at the end of the text
 * obj is the JQuery object that should be animated
 * text is the text that should be displayed in obj
 */
function ajaxAnimation(obj, text){
  obj.each(function(){
    var textObject = $(this);
    var curText = textObject.text();
    if(curText == text + '....'){
        textObject.text(text);
    }else{
        textObject.text(curText + '.');
    }
  });
}

/* Called when starting an AJAX operation. Disables report submission and starts the I/O indicator animation
 * obj is the JQuery object that should be animated as the I/O indicator
 * text is the text that should be displayed in obj
 */
function startAjaxLoading(obj, text){
    $('.ajaxSubmit').attr('disabled',true);
    obj.show().text(text);
    ajaxTimer = setInterval(function(){ajaxAnimation(obj,text)}, 250);
}

/* Update the report preview stub with new content based on the report settings */
function updatePreview(){
  if(isOkToSave()){
      var serialStr = getSerializedReportParameters(true);
      var errorMessage = 'There was an error connecting to the server to update the report preview';
//      alert(serialStr);
      ajaxRawPost($('#previewLoading'), 'Loading', 'updatePreview', serialStr, updateSections, errorMessage, true);
  }
}

/* Update the report preview stub with new content based on the report settings */
function loadPreview(){
  if(isOkToSave()){
      var serialStr = getSerializedReportParameters(true);
      var errorMessage = 'There was an error connecting to the server to update the report preview';
//      alert(serialStr);
      ajaxRawPost($('#previewLoading'), 'Loading', 'loadPreview', serialStr, updateSections, errorMessage, true);
  }
}

//Serialize the parameters for this report instance
function getSerializedReportParameters(projectIdFromSelection){
  //alert($('#startTime').val().replace(/:/g,'/').replace(' ', ''));
  var serial = '[startDate]:' + $('#startDate').val();
  serial += ';[startTime]:' +  $('#startTime').val().replace(/:/g,'/').replace(' ', '');
  serial += ';[endDate]:' + $('#endDate').val();
  serial += ';[endTime]:' +  $('#endTime').val().replace(/:/g,'/').replace(' ', '');
  if(projectIdFromSelection){
     serial += ';[projectid]:' + $("select[name='selectedProjectId']").val();
  }else{
      serial += ';[projectid]:' + $("#reportBody").find("input.projectId").val();
  }

  return serial;
}

/* Get the serialized representation of the entire report including user set data.
 * 
 */
function getSerializedString(){
    //Serialize the report parameters (date ranges, project id)
    var serial = getSerializedReportParameters(false);

    //Serialize each section
    $('.section').each(function(){
        var section = $(this);
        var path = section.children('.path').val();
        var sectionToggle = section.children('.sectionToggle[type=checkbox]:not(:checked)');

        //Check if the section is to be displayed. If not, there is no need to get all the data and pass it around
        if(sectionToggle.length>0){
            serial += ';' + path + '[visible]:false'; //Denote that this Section is not visible
        } 
//      else {
        //Handle the serialization of specific section types
        if(section.hasClass('textSection')){
            var stubText = section.children('.sectionContent').children('.textEditArea').children('.stub').children('.stubText');

            if(stubText.length==1){ //This should always be 1
                //Get the HTML to be displayed in the TextSection and escape special characters
                var text = stubText.html().replace(/;/gm,'\\;'); //escape any semicolons in the text
                text = text.replace(/\[/gm,'\\['); //escape any square brackets in the text
                text = text.replace(/:/gm,'\\:'); //escape any colons in the text
                    
                serial += ';' + path + '[text]:' + text; //Add the text for this section to the serialized string
            }else{
                //alert('No text for textSection?');
            }
            }else if(section.hasClass('casePlanningSection')){
            //Get all of the cases that were selected
            var checkedCases = section.find('input.selectedCases:checked');
                
            //If there were cases selected, then add them to the serialized string
            if(section.find('input.selectedCases:checkbox').length>0){
                var cases = '';
                checkedCases.each(function(){
                    cases += (cases.length > 0 ? ', ' : '') + this.value;
                });
                serial += ';' + path + '[cases]:' + cases;
            }
        }
//        }
    });

    //Replace special charactors with their URL safe equivilant
    serial = serial.replace(/&/gm,'%26');
    serial = serial.replace(/#/gm,'%23');

    //alert(serial);

    return serial;
}

/* Make an AJAX call to a raw page (no Fogbugz headers/footers) for a plugin
 * ioIndicator is the JQuery object that will notify the user that there is an AJAX operation taking place
 * indicatorText is the text that ioIndicator should display
 * page is the plugin page we want to load
 * serialStr is the serialized string for the report to send to the server
 * successCallback is a function that should be called when the POST request returns successfully
 * errorMessage is a message that should be displayed to the user if the POST request returns with an error
 */
function ajaxRawPost(ioIndicator, indicatorText, page, serialStr, successCallback, errorMessage, projectIdFromSelection){
    //Initialize the ioIndicator
    startAjaxLoading(ioIndicator, indicatorText);

    //Append the serialized report data to the AJAX POST data
    var pluginPrefix = $('#pluginPrefix').val();

    var ixProjectId;
    if(projectIdFromSelection){
      ixProjectId = $("select[name='selectedProjectId']").val();
    }else{
      ixProjectId = $("#reportBody").find("input.projectId").val();
    }
    var data = pluginPrefix + 'page=' + page + '&' + pluginPrefix + 'serial=' + serialStr + '&' + pluginPrefix + 'ixProject=' + ixProjectId;

    //Get the URL for a raw page (no Fogbugz headers/footers) for our plugin
    var rawPageUrl = $('#rawPageUrl').val();
    var url = rawPageUrl;
    
    //Make a POST request to the server if the server responds with a success redirect the user to the new wiki page
    $.ajax({
    url: url,
        type: 'POST',
        data: data,
        dataType:'html',
        success: successCallback,
        error: function(){
          ajaxDone(); //Hide the ioIndicator
          alert(errorMessage);
        }
    });
}

/* Generate the report and save it to the wiki
 * Serializes all of the report data and sends it off the server. Redirects the user to the new wiki page when it is ready.
 */
function generateReport(){
  var serialStr = getSerializedString();
  var errorMessage = 'There was an error connecting to the server to generate the report.';
  
  ajaxRawPost($('#savingSpan'), 'Saving', 'generateWiki', serialStr, reportGenerated, errorMessage, false)

}

/* Called when the report has been generated in the wiki. Redirects the user to the given url or displays an appropriate error
 * url is the URL of the wiki page that has been generated.
 */
function reportGenerated(url){
    ajaxDone();
    
    //Check for errors
    if(url.length<0){
      alert('There was an error connecting to the server to generate the report.');
    }else if(url == 'Error') {
        alert('Please Visit the settings page and set your preferences before generating the report for this project.');
    } else {
        document.location = url; //Load up the new wiki page
    }
}

function saveReport(){

    var serialStr = getSerializedString();
    var errorMessage = 'There was an error connecting to the server to generate the report.';
//alert('SAVE <br>' + serialStr);
  
    ajaxRawPost($('#savingSpan'), 'Saving', 'saveWiki', serialStr, reportSaved, errorMessage, false);
}

function reportSaved(html) {
    ajaxDone();
    edited = false;
    //alert(html);
}
