﻿function updateProjectData() {
    startAjaxLoadingSettingsPage($('#loadingSpan'),'Loading');
    var rawPageUrl = $('#rawPageUrl').val();
    var pluginPrefix = $('#pluginPrefix').val();

    var arr = document.getElementsByName('ixProjectSelectionBox'); //will be an array
    var projectID = arr[0].options[arr[0].selectedIndex].value;

	var url = rawPageUrl;
    var data = pluginPrefix + 'ixProject=' + projectID + '&' + pluginPrefix + 'page=projectUpdate';

    $.ajax({
		url: url,
        type: 'POST',
        dataType:'json',
        data: data,
		success: updateSectionsSettingsPage,
		error: function(){
            ajaxDoneSettingsPage();
			//alert('There was an error connecting to the server to update the settings');
			var errDiv = document.getElementById('errDiv');
			errDiv.innerHTML = '<h1 style="color: red;">There was an error connecting to the server to update the settings</h1>';
			errDiv.style.display = 'block';
		}
	});
}

function removeAllOptions(selectbox)
{
    var i;
    for(i=selectbox.options.length-1;i>=0;i--)
    {
        selectbox.remove(i);
    }
}

function updateSectionsSettingsPage(newData) {
    ajaxDoneSettingsPage();
	var err = newData['Error'];
	//alert(err);

	if(err == null) {
		var pluginPrefix = $('#pluginPrefix').val();

		var courseName = newData['courseName'];
		var cycleNumber = newData['cycleNumber'];
		var weekNumber = newData['weekNumber'];
		var startDate = newData['startDate'];
		var wiki = newData['wikiSelect'];
		var wikiPage = newData['wikiPageSelect'];
		var teamExclusions = newData['teamExclusions'];

		$('input[name=\'' + pluginPrefix + 'courseName\']').val(courseName);
		$('input[name=\'' + pluginPrefix + 'cycleNumber\']').val(cycleNumber);
		$('input[name=\'' + pluginPrefix + 'weekNumber\']').val(weekNumber);
		$('input[name=\'' + pluginPrefix + 'cycleStartDate\']').val(startDate);
                
		//alert(teamExclusions);

		//Default all to checked
		$('input[name=' + pluginPrefix + 'teamMembers]').attr('checked', true);

		//Uncheck the ones to not include
		var nonChecks = teamExclusions.split(',');
		for(var i=0; i < nonChecks.length; i++) {
			var noCheck = nonChecks[i];
			$('input[id=personnumber' + noCheck + ']').attr('checked', false);
		}

		var wikiSelect = $('select[name=\'' + pluginPrefix + 'ixWiki\']');
		wikiSelect.val(wiki);
		$('#idDropList_' + wikiSelect.attr('id') + '_oText').val(wikiSelect.find('option:selected').text());

		var wikiPageSelect = $('select[name=\'' + pluginPrefix + 'ixWikiPage\']');
		wikiPageSelect.val(wikiPage);
		$('#idDropList_' + wikiPageSelect.attr('id') + '_oText').val(wikiPageSelect.find('option:selected').text());
		var errDiv = document.getElementById('errDiv').style.display = 'none';
	} else {
		var errDiv = document.getElementById('errDiv');
		errDiv.innerHTML = '<h1 style="color: red;">No Settings for this Project Yet (' + err + ')</h1>';
		errDiv.style.display = 'block';
		//alert('Settings for Project not yet set. (' + err + ')');
	}
}

var ajaxTimerSettingsPage = null;

function ajaxDoneSettingsPage(){
    clearInterval(ajaxTimerSettingsPage);
    $('.ajaxSubmit').attr('disabled',false);
    ajaxTimerSettingsPage = null;
    $('.ajaxIndicator').hide();
}

function ajaxAnimationSettingsPage(obj, text){
    var curText = obj.text();
    if(curText == text + '....'){
        obj.text(text);
    }else{
        obj.text(curText + '.');
    }
}

function startAjaxLoadingSettingsPage(obj, text){
    $('.ajaxSubmit').attr('disabled',true);
    obj.show().text(text);
    ajaxTimerSettingsPage = setInterval(function(){ajaxAnimationSettingsPage(obj,text)}, 250);
} 
