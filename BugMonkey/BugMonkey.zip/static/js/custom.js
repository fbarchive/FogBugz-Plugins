$(document).ready(function() {
	(function(api) {
		var sPluginID = "BugMonkey@fogcreek.com";
		var ixTransactionNext = 0;

		// Load customization script for this user
		$.ajax({
			url: "?",
			data: {
				pg: "pgPluginBinary",
				sPluginID: sPluginID,
				"P_sView": "getjs",
				ix: api.setting("build") || 0,
				ixPerson: (window.GetPersonID ? GetPersonID() : -1)
			},
			cache: true,
			dataType: "text",
			success: function(js) {
				$.globalEval(js.substring(js.indexOf("\n")));
			}
		});

		// If we're not on the customizations page, we don't need to run the rest
		if (!$("#Customizations").length) return;

		var sCurrentHash;
		var sActionToken = $("#idCustomizationsActionToken").val();

		var wrapArgs = function(args) {
			var data = {
				pg: "pgPluginBinary",
				sPluginID: sPluginID,
				sActionToken: sActionToken
			};

			$.each(args, function(key, value) {
				if (value != undefined && value != null) {
					data["P_" + key] = value;
				}
			});

			return data;
		};

		var loadPermissionBlock = function(target, sAdd, sRemove, nActivation) {
			var permBlock = $(target);
			var permTitle;
			var permBody;
			var fSimple = permBlock.attr("nActTarget").toLowerCase() != "customization";

			if (!permBlock.attr("initialized")) {
				permBlock.attr("initialized", true);

				permTitle = $("<div>")
				.addClass("title")
				.text(permBlock.attr("blockTitle"))
				.appendTo(permBlock);

				permBody = $("<div>")
				.addClass("body")
				.text("Loading...")
				.appendTo(permBlock);
			}
			else {
				permTitle = permBlock.find(".title");
				permBody = permBlock.find(".body");
			}

			var ixTransaction = ixTransactionNext++;
			$(target).data("ixTransaction", ixTransaction);

			$.post("?",
				wrapArgs({
					sData: "permissionList",
					nActTarget: permBlock.attr("nActTarget"),
					ixActTargetValue: permBlock.attr("ixActTargetValue"),
					sAdd: sAdd,
					sRemove: sRemove,
					nActivation: nActivation
				}),
				function(data) {
					if (ixTransaction != $(target).data("ixTransaction")) return;

					if (data.fSuccess) {
						var table = $("<table>");

						var rgnActivationLevel = [2, 3, 9]; // Optional (Off), Optional (On), Required
						if (!fSimple) {
							var tr = $("<tr>").appendTo(table);
							$("<th>").addClass("custtitle").appendTo(tr);
							$("<th>").text("Default Off").attr("nActivation", rgnActivationLevel[0]).appendTo(tr);
							$("<th>").text("Default On").attr("nActivation", rgnActivationLevel[1]).appendTo(tr);
							$("<th>").text("Required").attr("nActivation", rgnActivationLevel[2]).appendTo(tr);
						}

						var sel = $("<select>").attr("img", 1);

						var fEmpty = true;

						$.each(data.list, function(ix, el) {
							var sPrefix = el.sPrefix;

							$.each(el.list, function(ix, el) {
								var ixOpt = el[0];
								var sText = el[1];
								var sImgUrl = el[2];
								var nActivationlevel = el[3];
								var fRequiredOnly = el[4];

								if (nActivationlevel == 0) { // TODO: Remove 0
									// Off
									var ixOpt = el[0];
									var sText = el[1];
									var sImgUrl = el[2];

									$("<option>")
									.val(sPrefix + "_" + ixOpt)
									.text(sText)
									.attr("img", sImgUrl)
									.attr("nActivation", fRequiredOnly ? rgnActivationLevel[2] : rgnActivationLevel[0])
									.appendTo(sel);
								}
								else {
									fEmpty = false;
									// On
									var tr = $("<tr>").appendTo(table);

									var td = $("<td>").appendTo(tr);

									$("<img>")
									.addClass("delete")
									.attr("src", StaticContentUrl("images/delete.png"))
									.appendTo(td)
									.click(function() {
										loadPermissionBlock(target, null, sPrefix + "_" + ixOpt);
									})

									if (sImgUrl) {
										$("<img>")
										.addClass("targetType")
										.attr("src", StaticContentUrl(sImgUrl))
										.appendTo(td);
									}

									$("<span>").text(sText).appendTo(td);

									if (!fSimple) {
										for (var i = 0; i < rgnActivationLevel.length; i++) {
											var td = $("<td>").appendTo(tr);

											var input = $("<input>")
											.attr("type", "radio")
											.attr("name", sPrefix + "_" + ixOpt)
											.val(rgnActivationLevel[i])
											.appendTo(td);

											input.prop("checked", rgnActivationLevel[i] === nActivationlevel);

											if (fRequiredOnly && rgnActivationLevel[i] != 9) {
												input.attr("disabled", "disabled");
											}
										}
									}
								}
							});
						});

						if (fEmpty) {
							var tr = $("<tr>").appendTo(table);
							var td = $("<td>").attr("colspan", fSimple ? 1 : rgnActivationLevel.length + 1).appendTo(tr);

							td.text("None");
						}

						permBody
						.empty()
						.append(table)
						.append(sel);

						$("<span>")
						.addClass("addToList")
						.text("Add")
						.appendTo(permBody)
						.click(function() {
							var select = $(this).siblings("select");

							if (fSimple) {
								loadPermissionBlock(target, select.val());
							}
							else {
								loadPermissionBlock(target, select.val(), null, select.find("option:selected").attr("nActivation"));
							}
						});

						if (!fSimple) {
							permBody
							.find("input[type=radio]")
							.bind($.browser.msie ? "propertychange" : "change", function() { // This should be changed to .change(...) with jQuery 1.4.2
								if ($(this).is(":checked")) {
									loadPermissionBlock(target, $(this).attr("name"), null, $(this).val());
								}
							})
						}

						DropListControl.refresh(sel[0]);
					} else {
						permBody.text("Load Error");
					}
				},
				"json"
			);
		};

		var processPermissionBlocks = function() {
			$("div.permissionBlock").each(function() {
				loadPermissionBlock(this);
			});
		};

		var custPrompt = function(args) {

			var removeOverlay = function() {
				$("div.overlay,div.promptBox").remove();
				$(".hasOverlay").removeClass("hasOverlay");
			};

			$("<div>")
			.addClass("overlay")
			.css("opacity", .5)
			.appendTo("body")
			.click(function() {
				removeOverlay();
				if (args.cancel) { args.cancel(); }
			});

			var width = args.width || 400;
			var height = args.height || 300;

			var promptBox = $("<div>")
			.addClass("promptBox")
			.css({
				width: width,
				height: height,
				"margin-left": -width / 2,
				"margin-top": -height / 2
			})
			.appendTo("body");

			var divTitle =
			$("<div>")
			.addClass("title")
			.text(args.sTitle || "Are you sure?")
			.height(32)
			.appendTo(promptBox);

			var divBody =
			$("<div>")
			.addClass("body")
			.height(height - 96)
			.css({
				"max-height": height - 96,
				overflow: "auto"
			})
			.text("Loading...")
			.appendTo(promptBox);

			Cust.loadPage(args.promptArgs, divBody, true);

			var divButtons =
			$("<div>")
			.addClass("buttons")
			.height(48)
			.appendTo(promptBox);

			$("<input>")
			.attr("type", "submit")
			.addClass("dlgButton")
			.val(args.sOK || "OK")
			.click(function() {
				$.post("?",
					wrapArgs(args.okArgs),
					function(data) {
						removeOverlay();
						if (data.fSuccess) {
							if (args.ok) { args.ok(); }
						}
					},
					"json"
				);
			})
			.appendTo(divButtons);

			$("<input>")
			.attr("type", "submit")
			.addClass("dlgButton")
			.val(args.sCancel || "Cancel")
			.click(function() {
				removeOverlay();
				if (args.cancel) { args.cancel(); }
			})
			.appendTo(divButtons);

			$("html,body")
			.addClass("hasOverlay");
		};

		var loadCustomizationList = function(target, ixCustEnable, ixCustDisable, rgixCustForceInclude, callback) {
			var listBlock = $(target);
			var listBody;

			rgixCustForceInclude = rgixCustForceInclude || [];

			if (!listBlock.attr("initialized")) {
				listBlock.attr("initialized", true);

				listBody = $("<div>")
				.addClass("body")
				.appendTo(listBlock);

				listBody.text("Loading...");
			}
			else {
				listBody = listBlock.find(".body");
			}

			var sListID = listBlock.attr("sListID");
			var fAdmin = IsAdmin();

			var ixTransaction = ixTransactionNext++;
			$(target).data("ixTransaction", ixTransaction);

			$.post("?",
				wrapArgs({
					sData: "customizationList",
					sListID: sListID,
					ixCustEnable: ixCustEnable,
					ixCustDisable: ixCustDisable,
					rgixCustForceInclude: rgixCustForceInclude.join(",")
				}),
				function(data) {
					if (ixTransaction != $(target).data("ixTransaction")) return;

					if (data.fSuccess) {
						var fShowDelete = data.fShowDelete;
						var fShowFrom = data.fShowFrom;

						var table = $("<table>");

						if (!data.list || !data.list.length) {
							listBody.text("None");
						}
						else {
							var trHeading = $("<tr>").appendTo(table);
							$("<th>").addClass("enabled").text("Enabled").appendTo(trHeading);
							$("<th>").addClass("custtitle").text("Title").appendTo(trHeading);
							if (fAdmin) {
								$("<th>").addClass("rules").text("Rules").appendTo(trHeading);
							}

							if (fShowDelete) {
								$("<th>").addClass("delete").text("Delete").appendTo(trHeading);
							}

							if (fShowFrom) {
								$("<th>").addClass("assignedby").text("From").appendTo(trHeading);
							}

							$.each(data.list, function(ix, cust) {
								var tr = $("<tr>")
								.addClass(cust.fEnabled ? "enabled" : "disabled")
								.appendTo(table);

								var tdEnabled = $("<td>").addClass("enabled").appendTo(tr);

								if (cust.fRequired || !(cust.fOptional || cust.fOwner)) {
									var fText = cust.fRequired ? "Required" : "Unavailable";

									var spanLink =
									$("<span>")
									.text(fText)
									.appendTo(tdEnabled);

									if (fAdmin) {
										spanLink
										.addClass("actionLink")
										.click(function() {
											Cust.loadPage({ sView: "rules", ixCust: cust.ixCust });
										});
									}
								}
								else {
									$("<span>")
									.addClass("actionLink")
									.text(cust.fEnabled ? "On" : "Off")
									.attr("sAction", "enableCust")
									.click(function() {
										var fEnabled = !cust.fEnabled;
										var ixCustToEnable = fEnabled ? cust.ixCust : null;
										var ixCustToDisable = fEnabled ? null : cust.ixCust;

										if ($.inArray(cust.ixCust, rgixCustForceInclude) == -1) {
											rgixCustForceInclude.push(cust.ixCust);
										}

										loadCustomizationList(
											target,
											ixCustToEnable,
											ixCustToDisable,
											rgixCustForceInclude,
											function() {
												if (fEnabled) {
													Cust.showMessage("Newly enabled customizations will take effect when you <a href=\"javascript:location.reload();\">refresh the page</a>", true);
												}
											}
										);
									})
									.appendTo(tdEnabled);
								}

								var tdName = $("<td>").addClass("custtitle").appendTo(tr);

								var aTitle = $("<span>")
								.text(cust.sName)
								.attr("title", cust.sDescription)
								.appendTo(tdName);

								if (cust.fOwner || fAdmin) {
									aTitle
									.addClass("actionLink")
									.click(function() {
										Cust.loadPage({ sView: "edit", ixCust: cust.ixCust });
									})
								}

								if (fAdmin) {
									var tdAssignable = $("<td>").addClass("rules").appendTo(tr);

									$("<span>")
									.addClass("actionLink")
									.text("Edit Rules...")
									.click(function() {
										Cust.loadPage({ sView: "rules", ixCust: cust.ixCust });
									})
									.appendTo(tdAssignable);
								}

								if (fShowDelete) {
									var tdDelete = $("<td>").addClass("delete").appendTo(tr);

									if (cust.fCanDelete) {
										$("<span>")
									.addClass("actionLink")
									.text("Delete...")
									.click(function() {
										custPrompt({
											promptArgs: { sView: "deleteprompt", ixCust: cust.ixCust },
											okArgs: { sAction: "delete", ixCust: cust.ixCust },
											sTitle: "Delete Customization?",
											ok: function() {
												loadCustomizationList(target, null, null, rgixCustForceInclude);
											}
										});
									})
									.appendTo(tdDelete);
									}
								}

								if (fShowFrom) {
									var tdAssignedBy = $("<td>").addClass("assignedby").appendTo(tr);

									if (cust.ixPersonAssignmentOwner) {
										var sText;

										if (cust.fRequired) {
											sText = "Required";
										}
										else {
											sText = "Shared";
										}

										$("<span>")
										.text(sText)
										.appendTo(tdAssignedBy);

										if (cust.ixPersonAssignmentOwner > 0) {
											$("<span>")
											.text(" by ")
											.appendTo(tdAssignedBy);

											$("<span>")
											.appendTo(tdAssignedBy)
											.html(cust.ixPersonAssignmentOwner == GetPersonID() ? "you" : GetPerson(cust.ixPersonAssignmentOwner));
										} else {
											// not assigned by an ixPerson; probably carried over from BugMonkey 1.0
										}
									}
									else if (cust.fOwner) {
										$("<span>")
										.text("Owned by you")
										.appendTo(tdAssignedBy);
									}
								}
							});

							listBody
							.empty()
							.append(table);
						}

						if (callback) {
							callback();
						}
					} else {
						listBody.text("Load Error");
					}
				},
				"json"
			);
		};

		var processCustomizationLists = function() {
			$("div.customizationList").each(function() {
				loadCustomizationList(this);
			});
		};

		var processListSelectors = function() {
			$("span.selectList")
			.click(function() {
				if ($(this).hasClass("selected")) return;

				$(this).siblings().removeClass("selected");
				$(this).addClass("selected");

				var divTarget =
				$(this)
				.closest("table")
				.find("div.listView")

				divTarget.empty();

				var divList =
				$("<div>")
				.addClass("customizationList")
				.attr("sListID", $(this).attr("sListID"))
				.appendTo(divTarget);

				loadCustomizationList(divList);
			});
		};

		var processEditRulesPopups = function() {
			$("span.editRules")
			.click(function() {
				var permBlock = $(this).next(".permissionBlock");

				permBlock.show();
				$(this).hide();

				fixDroplists(permBlock);
			});
		};

		var invalidate = function() {
			api.setting("build", 1 + (parseInt(api.setting("build")) || 0));
		};

		var fixDroplists = function(target) {
			// Update all the droplists
			$(target).find("select").each(function() { DropListControl.refresh(this); });
		};

		var fixHtml = function(target) {
			var jActionItems =
						$(target)
						.find("a,input[type=submit]");

			$.each(["sView", "sAction"], function(ix, attr) {
				jActionItems
				.filter("[" + attr + "]")
				.click(function() {
					var data = {};
					data[attr] = $(this).attr(attr);

					var srgParams = $(this).attr("srgParams");
					if (srgParams != null && srgParams.length > 0) {
						$.each(srgParams.split(","), function(ix, el) {
							data[el] = $("#" + el).val();
						});
					}
					Cust.loadPage(data);
				})
				.filter("[sidRequiredCheckbox]")
				.attr("disabled", "disabled")
				.each(function() {
					var btn = this;
					var cb = $("input[type='checkbox']").filter("[id='" + $(this).attr("sidRequiredCheckbox") + "']");
					cb.change(function() {
						if (cb.is(":checked")) {
							$(btn).removeAttr("disabled");
						}
						else {
							$(btn).attr("disabled", "disabled");
						}
					});
				});
			});

			fixDroplists(target);
		};

		var activatePage = function(target) {
			fixHtml(target);
			processPermissionBlocks();
			processCustomizationLists();
			processListSelectors();
			processEditRulesPopups();

			$("#sCust").bind("change keydown", function() { $("#CustomizationErrors").hide(); });
			$("span.toggleEnableCust").click(function() {
				var target = this;
				$.post("?",
					wrapArgs({ sAction: "toggleEnableCust", ixCust: $(this).attr("ixCust") }),
					function(data) {
						if (data.fSuccess) {
							$(target).text(data.fEnabled ? "Yes" : "No");
						}
						if (data.fEnabled) {
							Cust.showMessage("Newly enabled customizations will take effect when you <a href=\"javascript:location.reload();\">refresh the page</a>", true);
						}
					},
					"json"
				);
			});
		};

		var Cust = {
			init: function() {
				$(window).bind("hashchange", function(e) {
					var sNewHash = $.param.fragment();
					if (sNewHash != sCurrentHash) {
						Cust.loadPage($.deparam(sNewHash));
					}
				});

				if (window.location.hash) {
					$(window).trigger("hashchange");
				}
				else {
					$("#Customizations").each(activatePage);
				}

				invalidate(); // TODO: Be more specific about when this happens
			},

			showError: function(sError) {
				$("#CustomizationErrors")
				.removeClass("message")
				.addClass("error")
				.text(sError)
				.show()
				.yft();
			},

			showMessage: function(sMessage, fAllowHtml) {
				var divErrors = $("#CustomizationErrors");
				var fRepeat = false;

				divErrors
				.removeClass("error")
				.addClass("message");

				if (fAllowHtml) {
					fRepeat = (sMessage == divErrors.html());
					divErrors.html(sMessage);
				}
				else {
					fRepeat = (sMessage == divErrors.text());
					divErrors.text(sMessage);
				}

				divErrors
				.show();

				if (!fRepeat) {
					divErrors.yft();
				}
			},

			loadPage: function(args, target, fNoHistory) {
				if (args.sAction) {
					if (args.sAction == "back") {
						window.history.back();
					} else {
						$.post("?",
							wrapArgs(args),
							function(data) {
								if (data.fSuccess) {
									if (data.redirect) {
										Cust.loadPage(data.redirect);
									}
									if (data.sMessage) {
										Cust.showMessage(data.sMessage);
									}
									if (args.sAction == "apply") {
										$("div.requiresApply")
										.removeClass("requiresApply")
										.each(function() {
											$("#ixCust").val(data.ixCust);
											$(this).find("[ixCust]").attr("ixCust", data.ixCust);
											$(this).find("[ixActTargetValue]").attr("ixActTargetValue", data.ixCust);
										})
										.show();
									}
								}
								else {
									Cust.showError(data.sError);
								}
							},
							"json"
						);
					}
				} else {
					if (!fNoHistory) {
						sCurrentHash = $.param(args);
						window.location.hash = sCurrentHash;
					}

					$("#CustomizationErrors").hide();

					$(target || "#Customizations")
					.load("?", wrapArgs(args), function() {
						activatePage(this);
					});
				}
			}
		};

		Cust.init();

	})(new BugMonkey.api("BugMonkey"));
});

/*
* jQuery BBQ: Back Button & Query Library - v1.2.1 - 2/17/2010
* http://benalman.com/projects/jquery-bbq-plugin/
* 
* Copyright (c) 2010 "Cowboy" Ben Alman
* Dual licensed under the MIT and GPL licenses.
* http://benalman.com/about/license/
*/
(function($, p) { var i, m = Array.prototype.slice, r = decodeURIComponent, a = $.param, c, l, v, b = $.bbq = $.bbq || {}, q, u, j, e = $.event.special, d = "hashchange", A = "querystring", D = "fragment", y = "elemUrlAttr", g = "location", k = "href", t = "src", x = /^.*\?|#.*$/g, w = /^.*\#/, h, C = {}; function E(F) { return typeof F === "string" } function B(G) { var F = m.call(arguments, 1); return function() { return G.apply(this, F.concat(m.call(arguments))) } } function n(F) { return F.replace(/^[^#]*#?(.*)$/, "$1") } function o(F) { return F.replace(/(?:^[^?#]*\?([^#]*).*$)?.*/, "$1") } function f(H, M, F, I, G) { var O, L, K, N, J; if (I !== i) { K = F.match(H ? /^([^#]*)\#?(.*)$/ : /^([^#?]*)\??([^#]*)(#?.*)/); J = K[3] || ""; if (G === 2 && E(I)) { L = I.replace(H ? w : x, "") } else { N = l(K[2]); I = E(I) ? l[H ? D : A](I) : I; L = G === 2 ? I : G === 1 ? $.extend({}, I, N) : $.extend({}, N, I); L = a(L); if (H) { L = L.replace(h, r) } } O = K[1] + (H ? "#" : L || !K[1] ? "?" : "") + L + J } else { O = M(F !== i ? F : p[g][k]) } return O } a[A] = B(f, 0, o); a[D] = c = B(f, 1, n); c.noEscape = function(G) { G = G || ""; var F = $.map(G.split(""), encodeURIComponent); h = new RegExp(F.join("|"), "g") }; c.noEscape(",/"); $.deparam = l = function(I, F) { var H = {}, G = { "true": !0, "false": !1, "null": null }; $.each(I.replace(/\+/g, " ").split("&"), function(L, Q) { var K = Q.split("="), P = r(K[0]), J, O = H, M = 0, R = P.split("]["), N = R.length - 1; if (/\[/.test(R[0]) && /\]$/.test(R[N])) { R[N] = R[N].replace(/\]$/, ""); R = R.shift().split("[").concat(R); N = R.length - 1 } else { N = 0 } if (K.length === 2) { J = r(K[1]); if (F) { J = J && !isNaN(J) ? +J : J === "undefined" ? i : G[J] !== i ? G[J] : J } if (N) { for (; M <= N; M++) { P = R[M] === "" ? O.length : R[M]; O = O[P] = M < N ? O[P] || (R[M + 1] && isNaN(R[M + 1]) ? {} : []) : J } } else { if ($.isArray(H[P])) { H[P].push(J) } else { if (H[P] !== i) { H[P] = [H[P], J] } else { H[P] = J } } } } else { if (P) { H[P] = F ? i : "" } } }); return H }; function z(H, F, G) { if (F === i || typeof F === "boolean") { G = F; F = a[H ? D : A]() } else { F = E(F) ? F.replace(H ? w : x, "") : F } return l(F, G) } l[A] = B(z, 0); l[D] = v = B(z, 1); $[y] || ($[y] = function(F) { return $.extend(C, F) })({ a: k, base: k, iframe: t, img: t, input: t, form: "action", link: k, script: t }); j = $[y]; function s(I, G, H, F) { if (!E(H) && typeof H !== "object") { F = H; H = G; G = i } return this.each(function() { var L = $(this), J = G || j()[(this.nodeName || "").toLowerCase()] || "", K = J && L.attr(J) || ""; L.attr(J, a[I](K, H, F)) }) } $.fn[A] = B(s, A); $.fn[D] = B(s, D); b.pushState = q = function(I, F) { if (E(I) && /^#/.test(I) && F === i) { F = 2 } var H = I !== i, G = c(p[g][k], H ? I : {}, H ? F : 2); p[g][k] = G + (/#/.test(G) ? "" : "#") }; b.getState = u = function(F, G) { return F === i || typeof F === "boolean" ? v(F) : v(G)[F] }; b.removeState = function(F) { var G = {}; if (F !== i) { G = u(); $.each($.isArray(F) ? F : arguments, function(I, H) { delete G[H] }) } q(G, 2) }; e[d] = $.extend(e[d], { add: function(F) { var H; function G(J) { var I = J[D] = c(); J.getState = function(K, L) { return K === i || typeof K === "boolean" ? l(I, K) : l(I, L)[K] }; H.apply(this, arguments) } if ($.isFunction(F)) { H = F; return G } else { H = F.handler; F.handler = G } } }) })(jQuery, this);
/*
* jQuery hashchange event - v1.2 - 2/11/2010
* http://benalman.com/projects/jquery-hashchange-plugin/
* 
* Copyright (c) 2010 "Cowboy" Ben Alman
* Dual licensed under the MIT and GPL licenses.
* http://benalman.com/about/license/
*/
(function($, i, b) { var j, k = $.event.special, c = "location", d = "hashchange", l = "href", f = $.browser, g = document.documentMode, h = f.msie && (g === b || g < 8), e = "on" + d in i && !h; function a(m) { m = m || i[c][l]; return m.replace(/^[^#]*#?(.*)$/, "$1") } $[d + "Delay"] = 100; k[d] = $.extend(k[d], { setup: function() { if (e) { return false } $(j.start) }, teardown: function() { if (e) { return false } $(j.stop) } }); j = (function() { var m = {}, r, n, o, q; function p() { o = q = function(s) { return s }; if (h) { n = $('<iframe src="javascript:0"/>').hide().insertAfter("body")[0].contentWindow; q = function() { return a(n.document[c][l]) }; o = function(u, s) { if (u !== s) { var t = n.document; t.open().close(); t[c].hash = "#" + u } }; o(a()) } } m.start = function() { if (r) { return } var t = a(); o || p(); (function s() { var v = a(), u = q(t); if (v !== t) { o(t = v, u); $(i).trigger(d) } else { if (u !== t) { i[c][l] = i[c][l].replace(/#.*/, "") + "#" + u } } r = setTimeout(s, $[d + "Delay"]) })() }; m.stop = function() { if (!n) { r && clearTimeout(r); r = 0 } }; return m })() })(jQuery, this);