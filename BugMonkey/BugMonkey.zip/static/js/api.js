﻿window.BugMonkey = {};

window.BugMonkey.api = function(sId) {
	this.sId = sId;
};

window.BugMonkey.api.prototype = (function(undefined) {
	var storage = window.localStorage;

	return {
		version: "1.0.0",
		// Read a value: api.setting("foo");
		// Write a value: api.setting("foo", "bar");
		setting: function(key, value) {
			var name = this.sId + "_" + key;
			if (value === undefined) {
				return storage ? storage[name] : getCookie(name);
			}
			else if (storage) {
				storage[name] = value;
			}
			else {
				setCookie(name, value);
			}
		}
	};
})();