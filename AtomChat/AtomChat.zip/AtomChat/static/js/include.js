$(document).ready(function() {

	at_name = document.getElementById('username').innerHTML;	
	at_host = location.host.toLowerCase().replace(/[^a-zA-Z]+/g, "");

	var css = document.createElement("link");
	css.setAttribute("href",'//'+at_host+'.cdn.atomchat.com/c');
	css.setAttribute("media","screen");
	css.setAttribute("rel","stylesheet");
	css.setAttribute("type","text/css");
	document.head.appendChild(css);
	
	var js = document.createElement('script');
	js.src = '//'+at_host+'.cdn.atomchat.com/j';
	js.setAttribute('async', 'true');
	document.documentElement.firstChild.appendChild(js);

});