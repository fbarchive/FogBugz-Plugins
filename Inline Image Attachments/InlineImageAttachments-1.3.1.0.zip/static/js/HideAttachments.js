$(document).ready(function() {
    var hideAttachments = function() {
        $('.bugEvent[hide]').each(function() {
            var parts = $(this).attr('hide').split('|');
            if (parts.length == 2) {
                var ixBugEvent = parts[0];
                var sFilename = parts[1];
                $("#containerAttachmentList_" + ixBugEvent + " .bugEvent:has(a[href*='sFileName=" + sFilename + "'])").hide();
            }
            else if (parts.length == 3) {
                var ixBugEvent = parts[0];
                var sFilename = parts[1];
                var ixAttachment = parts[2];
                $("#containerAttachmentList_" + ixBugEvent + " .attachment:has(a[href*='ixAttachment=" + ixAttachment + "'])").hide();
            }
        });
    }
    hideAttachments();
    $('#bugEventHistory').bind("ajaxComplete", hideAttachments).bind("changeBug", hideAttachments);
});