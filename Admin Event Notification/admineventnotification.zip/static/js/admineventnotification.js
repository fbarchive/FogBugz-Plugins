﻿var AdminEventNotificationPlugin = new function($){
	var oSelf = this;
	var rgAreaProject;

	this.SetupAreaProjectMapping = function()
	{
		rgAreaProject			= DB.Area.select();

		rgAreaProject.foreach(function(_) { _.ix = _.ixArea; _.s = _.sArea; _.ixP = _.ixProject; });
	}


	this.projectChanged = function (x)
	{
		var elProject = $('.project', document.formWithProject).get(0);
		
		if($('.area', document.formWithProject).length > 0){
			// AREA
			var elArea = $('.area', document.formWithProject).get(0);
			elArea.innerHTML = '';
			var opts = elArea.options;

			var ixNew = 0;
			var i;
			for (i=0; i<rgAreaProject.length; i++)
			{
				if (rgAreaProject[i].ixP == elProject.options[x].value) 
				{
					opts[ixNew]=new Option(decodeLTGT(rgAreaProject[i].s), rgAreaProject[i].ix);
					ixNew++;
				}
			}

			if (window.opera) redraw(elArea);

			opts[0].selected = true;
				
		}

		// BugzId: 2000592 
		// In empty cache cases on Chrome, not having the setTimeout
		// can cause a race condition whereby the droplists aren't refreshed
		// properly
		setTimeout(function () {
			DropListControl.refreshWithin(document.formWithProject);
		}, 1);
	};

	$(function(){
		if($("#formWithProject").length > 0){
			oSelf.SetupAreaProjectMapping();
			$(".project").change(function(){
				oSelf.projectChanged(this.options.selectedIndex);
			});
		}
	});
}(jQuery);