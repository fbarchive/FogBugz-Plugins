﻿$(document).ready(function () {
    $("input#interval_All").click(function () {
        if ($(this).attr('checked') == true) {
            $(':checkbox:not(this)').attr('checked', true);
        }
        else {
            $(':checkbox:not(this)').attr('checked', false);
        }
    });
});


var FogBookzPlugin = new function () {
    var oSelf = this;

    this.doPopup = function (elPopupAnchor) {
        oSelf.Popup.setHtml(
    '<form id="FogBookzNotesEditPopup" onsubmit="return false;">' +
    '<div class="dialog dialog-double-col" style="width: 400px;">' +
        '<p id="FogBookzNotesTitle" class="dialog-title">Notes for Interval</p>' +
        '<table cellspacing="0" width="100%">' +
        '<tbody>'+
        '<tr class="dialog-item   "><th class="dialog-item-label dialog-double-col-cell" style="width: ">Notes:</th><td class="dialog-double-col-cell">' +
        '<div class="dialog-item-content">' +
        '<textarea maxlength="4000" rows="5" id="FogBookzNotes"></textarea></div></td></tr>' +
        '<tr class="dialog-item    dialog-item-last"><th class="dialog-item-label dialog-double-col-cell" style="width: "></th><td class="dialog-double-col-cell">' +
        '<div class="dialog-item-content">' +
        '<input type="submit" onclick="setNotes();FogBookzPlugin.Popup.hide(); return false; " name="OK" class="dlgButton" value="OK" chotkey="o" id="id_0">' +
        '<input type="submit" onclick="FogBookzPlugin.Popup.hide();return false; " name="OK" class="dlgButton" value="Cancel" chotkey="c" id="id_1">' +
        '</div></td></tr></tbody></table></div></form>');
        oSelf.Popup.showPopup(elPopupAnchor);
        return false;
    }

    this.OwnerAllSelected = function (taskId) {
        jQuery('select[name*="owner_"]').each(function () {
            jQuery(this).val(taskId);
            DropListControl.refresh(jQuery(this)[0]);
        });
    }
    this.CustomerJobAllSelected = function (staffId) {
        jQuery('select[name*="customer_"]').each(function () {
            jQuery(this).val(staffId);
            DropListControl.refresh(jQuery(this)[0]);
        });
    }

    this.ServiceAllSelected = function (staffId) {
        jQuery('select[name*="serviceItem_"]').each(function () {
            jQuery(this).val(staffId);
            DropListControl.refresh(jQuery(this)[0]);
        });
    }

    $(document).ready(function () {
        oSelf.Popup = api.PopupManager.newPopup("FogBookzPluginDialog");
    });
} ();


