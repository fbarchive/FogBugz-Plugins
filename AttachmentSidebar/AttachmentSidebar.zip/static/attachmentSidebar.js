﻿(function() {
    $(function() {
        $('#AttachmentSidebarPluginLinks a.permalink').click(function() {
            var ixBugEvent = $(this).attr('ixbugevent'),
                ixBug = $(this).attr('ixbug'),
                fxnYftBugEvent = function() {
                    $('#bugevent_' + ixBugEvent).yft();
                };
            var jBulkEditRow =  $('#miniBugList tr[ixBug=' + ixBug + ']:not(.selected)');
            if (jBulkEditRow.length) {
                $(document).one('loadBug', function(e, ixBugLoaded) {
                    if (ixBug == ixBugLoaded) setTimeout(fxnYftBugEvent, 500);
                });
                jBulkEditRow.click();
            } else {
                fxnYftBugEvent();
            }
        });
    });
})();