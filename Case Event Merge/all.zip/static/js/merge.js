﻿var CaseMergePlugin = new function($){
	var oSelf = this;

	// Move the "display in other case" content to the correct location
	this.setStatusChange = function(){
		$("#ixStatus").live("change", function(){
			$(".displayInDuplicate .content .mergeDisplay").insertAfter("#sDuplicatesEdit");
		});
	};

	oSelf.updateMergeText = function(){
		var cases = new Array();
		$(".displayInDuplicate .content .multiMergeList .singleItems li").each(function(){
			if($(this).find('input[type=checkbox]').prop('checked')){
				cases.push($(this).find("label a.vb").clone().wrap('<div>').parent().html());
			}
		});

		var $mergeText;

		if(cases.length > 0){
			var lastElement = cases.pop();
			var caseText = lastElement;
			if(cases.length > 0){
				var firstElements = cases.join(', ');
				caseText = firstElements + " and " + lastElement;
			}
			$mergeText = $(CASEMERGE_CASES_SHOWN_TEXT);
			$mergeText.find(".mergeCases").html(caseText);
		} else {
			$mergeText = $(CASEMERGE_NO_CASES_SHOWN_TEXT);
		}

		$(".mergeText").replaceWith($mergeText);
	};

	this.updateAllStatus = function(){
		$(".multiMergeList").each(function(){
			var checked = $(this).find(".singleItems input[type=checkbox]:checked").length;
			var total = $(this).find(".singleItems input[type=checkbox]").length;
			if(checked == 0){
				$(this).find(".all").prop("checked", false).prop("indeterminate", false);
			} else if(checked == total){
				$(this).find(".all").prop("checked", true).prop("indeterminate", false);
			} else {
				$(this).find(".all").prop("checked", false).prop("indeterminate", true);
			}
		});
	};

	this.createPopup = function(){
		oSelf.Popup = api.PopupManager.newPopup("CaseMergePluginDialog");	  
		oSelf.Popup.setHtml($("#multiMergePopup").html() + 
		  '<br /><input type="submit" value="' + FB_DONE + '" class="dlgButton" id="CaseMergePopupClose">'
		);
		$("#CaseMergePopupClose").click(function(event){
			event.preventDefault();
			oSelf.Popup.hide();
		});
		$("#mergeLink").click(function(event){
			event.preventDefault();
			oSelf.Popup.showPopup(this);
		});
		$(".singleItems input").live("change", function(){
			$(".singleItems input[name=" + $(this).prop("name") + "]").prop("checked", $(this).prop("checked"));
			oSelf.updateAllStatus();
			oSelf.updateMergeText();
		});
		$(".multiMergeList .all").live("change", function(){
			$(".multiMergeList .all").prop("checked", $(this).prop("checked"));
			$(".singleItems input[type=checkbox]").prop("checked", $(this).prop("checked"));
			oSelf.updateMergeText();
		});

	};

	$(function(){
		// trigger on status change
		oSelf.setStatusChange();
		// trigger initial state
		$("#ixStatus").trigger("change");
		// create popup for multi merge
		if($("#multiMergePopup").length > 0){
			oSelf.createPopup();
			oSelf.updateAllStatus();
		}
		// display brief bug events with attachments
		$(".bugevent.brief .attachments .attachment").parents(".bugevent").addClass("containsAttachment");
	});
}(jQuery);