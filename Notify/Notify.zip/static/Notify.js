﻿var NotifyPlugin = new function() {

    this.UserNames = function() {
        if (typeof DB !== "object" || typeof DB.Person !== "object") {
            return [];
        }
        var retval = $.map(
          DB.Person.select(function(person) { return !(person.fDeleted || person.fCommunity); }),
          function(person) { return person.sFullName; });
        return retval;
    };

    this.UniqueCandidateName = function(s) {
        var sUpper = s.toUpperCase();

        // Return any exact matches
        // (special case for one user having a name that is a substring of another user's name)
        var rgsExact = $.grep(NotifyPlugin.UserNames(),
          function(sName) { return sName.toUpperCase() === sUpper; });
        if (rgsExact.length === 1) {
            return rgsExact[0];
        }

        // If the substring uniquely identifies the user, return that
        var rgsCandidate = $.grep(NotifyPlugin.UserNames(),
          function(sName) { return sName.toUpperCase().indexOf(sUpper) > -1; });
        if (rgsCandidate.length === 1) {
            return rgsCandidate[0];
        }

        return "";
    };

    this.ValidUserName = function(s) {
        return NotifyPlugin.UniqueCandidateName(s) !== "";
    };

    this.CanonicalUserName = function(s) {
        var sUnique = NotifyPlugin.UniqueCandidateName(s);
        return sUnique === "" ? s : sUnique;
    };

} ();