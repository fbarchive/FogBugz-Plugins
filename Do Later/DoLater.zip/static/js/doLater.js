﻿(function () {
    var N_ACTION_NONE = 0;
    var N_ACTION_NOTIFY_ME = 1;
    var N_ACTION_ACTIVATE_AND_ASSIGN_TO_ME = 2;

    function addDoLaterTrigger() {
        var fUseActivate;
        var inputDoLaterDate = $('input#DoLater_Date');
        var inputDoLaterTime = $('input#DoLater_Time');
        var sSelectDoLaterAction = 'select[name*="DoLater_nAction"]';
        var droplistDoLaterAction = $(sSelectDoLaterAction);

        if (!$('#bugviewContainer').length || !inputDoLaterDate.length) {
            return;
        }

        inputDoLaterDate.on("change", function (event) {

            //set the time if empty
            fSetTimeToWorkdayStart = inputDoLaterTime.val() === GetLocaleTime() || inputDoLaterTime.val() === '';
            if (fSetTimeToWorkdayStart) {
                inputDoLaterTime.val(CTZGetWorkdayStart());
            }

            //set the action if it's currently -- None --
            if (parseInt(droplistDoLaterAction.val(), 10) === N_ACTION_NONE) {
                fUseActivate = (droplistDoLaterAction.find('option[value="' + N_ACTION_ACTIVATE_AND_ASSIGN_TO_ME + '"]').length !== 0);
                droplistDoLaterAction.val(fUseActivate ? N_ACTION_ACTIVATE_AND_ASSIGN_TO_ME : N_ACTION_NOTIFY_ME);
                DropListControl.refresh(droplistDoLaterAction[0]);
            }
        });
    }
    addDoLaterTrigger();
    $(window).on('BugViewChange', addDoLaterTrigger);
} ()); 