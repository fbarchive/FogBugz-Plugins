﻿

var BugzTop = new function () {
    var fLoaded = false;
    var oSelf = this;
    var elClickedRow = null;

    this.disable = function () {
        this.doCasePopup = function () { return true; };
    };

    this.enable = function () {
        this.doCasePopup = this.doCasePopupFn;
    };


    function target(uidTarget, fAbove) {
        this.uidTarget = uidTarget;
        this.fAbove = fAbove;
    }

    this.doCasePopupFn = function (el) {
        var ixBug = parseInt($(el).attr("ixBug"));

        return doRawPopup(el, ixBug);
    };


    var cancel = '"BugzTop.Popup.hide();return false;"';
    function doRawPopup(elPopupAnchor, ixBug) {

        oSelf.Popup.setHtml(
			'<form id="BugzTopForm" onsubmit="return BugzTop.submitPopup(' + ixBug + ');">\n' +
				'<h1><label for="iBugzTop"><nobr>BugzTop</nobr></label></h1>' +

				'<div id="edit_html" title="Edit"><textarea rows="15" id="bugztopedit" name="html" style="width:100%"></textarea></div>' +
                '<div class="editInstructions" style="margin-bottom: 8px;"><nobr>This will be visible at the top of the case.</nobr></div>' +
				'<div id="backlogError" style="display: none; color: red;">invalid something</div>' +
				'<br /><nobr><input type="submit" value="' + FB_OK + '" class="dlgButton"> ' +
				'<input type="button" onclick=' + cancel + ' value="' + FB_CANCEL + '" class="dlgButton"></nobr>' +
			'</form>' +
            '');
        oSelf.Popup.showPopup(elPopupAnchor);
        return false;
    }

    this.setHtmlData = function (ixBug, html) {
        var excaped = escape(html);

        // send the ajax request to update things on the server
        var sUrl = oSelf.PluginRawPageUrl + "&" +
			oSelf.PluginPrefix + "pre=" + oSelf.PreSet + "&" +
			oSelf.PluginPrefix + "ix=" + ixBug;

        // +"&" +
        var sdata = oSelf.PluginPrefix + "htmldata=" + excaped;

        jQuery.post(sUrl, sdata, function (ajaxdata) {
            if (ajaxdata != null && ajaxdata.text != "Error") {
                if (UpdateBugzTop(ajaxdata)) {
                    UpdateEvent(ajaxdata);
                }

            }
        });
    };

    function UpdateBugzTop(jXML) {
        var html = jQuery("BugzTopHTML", jXML).text();

        // see if we can find our div
        var mydiv = jQuery('#bugzTopDisplay');
        if (mydiv == null || mydiv.length == 0) {
            // force the reload of the page
            window.location.reload();
            return false;
        }
        else {
            jQuery('#bugzTopDisplay').htmlEval(html);
            BugzTop.EditorData = html;
        }

        return true;
    }

    function UpdateEvent(jXML) {
        //doReplaceBugEvents(jQuery("BugEventsHTML", jXML).text());

        var ixBugEventLatestNew = $("ixBugEventLatest", jXML).text();
        if (null != ixBugEventLatestNew && ixBugEventLatestNew != ixBugEventLatest) {
            ixBugEventLatest = ixBugEventLatestNew;
            var bugEventHTML = $("BugEventsHTML", jXML).text();
            if (bugEventHTML) {
                document.formWithProject.ixBugEventLatest.value = ixBugEventLatest;

                if (window.mozilla) saveSelection(el);

                var jelBelow = $("#newBugEventInsertBelowPoint");
                var jelAbove = $("#newBugEventInsertAbovePoint");

                if (jelBelow.length) {
                    jelBelow.htmlEval(bugEventHTML + jelBelow.html());
                    initEmailActionsMore(jelBelow);
                }
                else {
                    jelAbove.htmlEval(jelAbove.html() + bugEventHTML);
                    initEmailActionsMore(jelAbove);
                }

                shrinkImagesToFit();
                if (window.mozilla) restoreSelection(el);
            }
        }
    }

    this.submitPopup = function (ixBug) {
        var data = CKEDITOR.instances.bugztopedit.getData();
        oSelf.Popup.hide();
        oSelf.setHtmlData(ixBug, data);
        return false;
    };

    function getRawProjectName(ixProject) {
        var proj = DB.Project.select(function (row) { return row.ixProject === ixProject });
        if (proj.length !== 1)
            return 'N/A';
        else
            return proj[0].sProject;
    }

    function errMsg(sClass) {
        $("div.BugzTopGridContainer." + sClass)
			.parents("td")
			.click(function () {
			    var sErr = "err";
			    var sHeader = sErr;
			    switch (sClass) {
			        case 'NotEditable':
			            sErr = 'not writable';
			            sHeader = 'header not writable';
			            break;
			        case 'Closed':
			            sErr = 'bug closed';
			            sHeader = 'bug closed header';
			            break;
			    }

			    oSelf.Popup.setHtml('<h1>' + sHeader + '</h1><div style="width:300px;color:red;">' + sErr + '</div><br/><div><form onsubmit=' + cancel + '><input type="submit" onclick=' + cancel + ' value="' + FB_OK + '" class="dlgButton" /></form></div>');
			    oSelf.Popup.showPopup(this);
			});
    }


    $(document).ready(function () {
        oSelf.enable();
        oSelf.Popup = api.PopupManager.newPopup("BugzTop");
    });
} ();


function SetEditor() {

    window.g_sTemplateStylesheetUrl = "";
    window.g_defaultFontFamily = "Cambria,Georgia,'Times New Roman',Times,serif";

    var config = {};

    config.uiColor = '#B1C9DD';

    config.disableNativeSpellChecker = false;
    config.toolbarCanCollapse = false;
    config.resize_enabled = false;
    config.bodyId = 'www-fogcreek-com-fogbugz'; // Allows the styles to apply to the HTML inside the editor.
    config.bodyClass = 'article-content ckeditor-body'
    //config.contentsCss = ;
    config.tableClass = 'Basic';

    // Kind of silly, but we have to duplicate this list from
    // config.js; it's the list of default plugins NOT to load
    config.removePlugins = [
		'a11yhelp',
		'about',
		'bidi',
		'contextmenu',
		'dialogadvtab',
		'div',
		'elementspath',
		'filebrowser',
		'find',
		'flash',
		'forms',
		'horizontalrule',
		'image',
		'link',
		'maximize',
		'newpage',
		'pagebreak',
		'pastefromword',
		'pastetext',
		'popup',
		'save',
		'scayt',
		'showborders',
		'specialchar',
		'table',
		'templates',
		'wsc',
        'tab'
	].join(',');

    config.skin = 'kama';  
   // config.format_tags = 'p;pre;h1;h2;h3;h4;h5;h6;strike;u;em;blockquote;li;ou;ul;span';

    config.toolbar_Foo = [
		['Undo', 'Redo', '-'],
		['Bold', 'Italic', 'Underline', 'Strike', 'Blockquote'],
		['NumberedList', 'BulletedList', 'Outdent', 'Indent'],
		['Source']
	];
    config.toolbar = 'Foo';

    // NOTE: We *must* have the following FBmenuItems, because a bunch of the plugins
    // expect we'll have it (and that it will contain things like entries
    // for 'Cut', 'Copy', etc)

    var sSprite = StaticContentUrl('images/icons_drop.gif');
    CKEDITOR.FBmenuItems = {
        Picture: {
            sLabel: 'Picture',
            sCommand: 'FBimage',
            image: { sprite: sSprite, top: -462 }
        },
        Attachment: {
            sLabel: 'Attachment',
            sCommand: 'FBattachment',
            image: { sprite: sSprite, top: -580 }
        },
        Undo: {
            sLabel: 'Undo',
            title: 'Undo (Ctrl+Z)',
            sCommand: 'undo',
            sKeyBinding: 'Ctrl+Z',
            ckKeyBinding: CKEDITOR.CTRL + 90, //Z
            image: { sprite: sSprite, top: -22 }
        },
        Redo: {
            sLabel: 'Redo',
            title: 'Redo (Ctrl+Y)',
            sCommand: 'redo',
            sKeyBinding: 'Ctrl+Y',
            ckKeyBinding: CKEDITOR.CTRL + 89, //Y
            image: { sprite: sSprite, top: -42 }
        },
        Cut: {
            sLabel: 'Cut',
            sCommand: 'cut',
            sKeyBinding: 'Ctrl+X',
            image: { sprite: sSprite, top: -502 }
        },
        Copy: {
            sLabel: 'Copy',
            sCommand: 'copy',
            sKeyBinding: 'Ctrl+C',
            image: { sprite: sSprite, top: -522 }
        },
        Paste: {
            sLabel: 'Paste',
            sCommand: 'paste',
            sKeyBinding: 'Ctrl+V',
            image: { sprite: sSprite, top: -542 }
        },
        All: {
            sLabel: 'Select All',
            sCommand: 'selectAll',
            sKeyBinding: 'Ctrl+A'
        },
        Bold: {
            sCommand: 'bold',
            title: 'Bold (Ctrl+B)',
            ckKeyBinding: CKEDITOR.CTRL + 66 /*B*/
        },
        Italic: {
            sCommand: 'italic',
            title: 'Italic (Ctrl+I)',
            ckKeyBinding: CKEDITOR.CTRL + 73 /*I*/
        },
        Underline: {
            sCommand: 'underline',
            title: 'Underline (Ctrl+U)',
            ckKeyBinding: CKEDITOR.CTRL + 85 /*U*/
        }
    };

    if ($.browser.msie) {
        // If we're in IE, we apply an additional stylesheet which makes
        // it easier to select content (it makes sure the body fills the whole window)
        config.contentsCss =
                $.merge(
                        $.isArray(config.contentsCss) ? config.contentsCss : [config.contentsCss],
                        [CKEDITOR.basePath + "contents.ie.css"]
                );
    }

    config.keystrokes = [];
    $.each(CKEDITOR.FBmenuItems, function () {
        if (this.ckKeyBinding) {
            if (typeof this.ckKeyBinding === 'number') {
                config.keystrokes.push([this.ckKeyBinding, this.sCommand]);
            } else {
                for (var ix = 0; ix < this.ckKeyBinding.length; ix++) {
                    config.keystrokes.push([this.ckKeyBinding[ix], this.sCommand]);
                }
            }
        }
    });

    // NOTE: We must have this, because a bunch of the plugins expect we will
    CKEDITOR.contextMenuOverride = {};

    config.customConfig = '';

    var editor = CKEDITOR.instances['bugztopedit'];
    if (editor) CKEDITOR.remove(editor);
    editor = null;

    $('#bugztopedit').ckeditor(function () { }, config);
    $('#bugztopedit').val(BugzTop.EditorData);
}

