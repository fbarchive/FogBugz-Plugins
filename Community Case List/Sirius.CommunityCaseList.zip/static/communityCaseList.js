﻿$(document).ready(function() {
	if ($("#Menu_Settings").size()==1) {
		$("a[href='default.asp?pg=pgPublicViewForm']").attr("href", "default.asp?pg=pgPlugin&sPluginID=communitycaselist%40fogbugz.sirius.ch");
		$("a[href='default.asp?pg=pgCommunityList']").attr("href", "default.asp?pg=pgPlugin&sPluginID=communitycaselist%40fogbugz.sirius.ch&fCommunityList=1");
	}
});