﻿var dpp_callbackURL;
var dpp_pluginPrefix;
var dpp_pluginID;
var AjaxLoadsRemaining=0;

$(document).ready(
                    function() {
                        if (DiscussPlus_onTopicListPage()) {
                            dpp_callbackURL = DiscussPlus_getPostBackURL();
                            if (dpp_callbackURL) {
                                dpp_pluginPrefix = DiscussPlus_getPluginPrefixFromCallBackUrl(dpp_callbackURL);
                                dpp_pluginID = DiscussPlus_getPluginIDFromCallBackUrl(dpp_callbackURL);
                                if (DiscussPlus_ShowGridView()) {
                                    tablifyDiscussionList();
                                    DiscussPlus_LoadAdditionalDetails();
                                }
                                DiscussPlus__AddViewToggleMenu();
                            }
                        }

                        if (DiscussPlus_onTopicItemPage()) {
                            $(".dp_CaseStatusBoxTitle").click(function() {
                                $(".SortIconClose").toggle();
                                $(".SortIconOpen").toggle();
                                $(this).next().slideToggle('medium', function() {
                                    $(this).prev().toggleClass('roundAllCorners');
                                }
                                                                                          );
                            }
                                                        )
                        }
                    }
);

function tablifyDiscussionList() {

    var ajaxLoaderHTML = "&nbsp;";
    var outerDiv = $("#containerDiscussTopics");
    var outerSpans = outerDiv.children("span");

    if (outerDiv.children("span:first").text() == "No topics were found that matched.") return;
    
    outerDiv.hide();  
    outerDiv.children("br").remove();
    
    var newTbl = $("<table>").attr('id','dppTblTopics').addClass('biglist').addClass('dppTopics').addClass('tablesorter');
    newTbl.prepend("<thead><tr><th class='dppCellHead center'> </th><th class='dppCellHead center'>Cases</th><th class='dppCellHead center'> Topic </th><th class='dppCellHead center'> User </th><th class='dppCellHead center'> Views </th><th class='dppCellHead center'> Comments </th><th class='dppCellHead center'> Updated </th></tr></thead>");
    newTbl.append("<tbody id='dppTblTopicsBody'></tbody>");
        
    outerDiv.prepend(newTbl);
   
    var newTblBody = $("#dppTblTopicsBody");

    //build table from list view
    outerSpans.each(function(i) {
                        var discussLink = $(this).children("a.discuss,a.discussSpam");
                        var authorLink = $(this).children("em");
                        var commentText = $(this).children("span").text();                        
                        var starHTML = '';
                        var topicID = DiscussPlus_getTopicIdFromURL(discussLink.attr('href'));
                        
                        var newRow = "<tr class='row' id='dppTopicRow" + topicID + "' name='" + topicID +"'>" +
                                         getTdOpenTag('dppStar',topicID) + starHTML + "</td>" +
                                         getTdOpenTag('dppBugIcon',topicID) + ajaxLoaderHTML + "</td>" +
                                         getTdOpenTag('dppTopicLink',topicID) + DiscussPlus_outerHTML(discussLink) + "</td>" +
                                         getTdOpenTag('dppAuthorName',topicID) + authorLink.html() + "</td>" +
                                         getTdOpenTag('dppViewCount',topicID) + ajaxLoaderHTML + "</td>" +
                                         getTdOpenTag('dppCommentCount',topicID) + DiscussPlus_fixCommentColumnText(commentText) + "</td>" +
                                         getTdOpenTag('dppLastMod',topicID) + ajaxLoaderHTML + "</td>" +
                                     "</tr>";
                        var insertedRow = newTblBody.append(newRow).children("#dppTopicRow" + topicID);
                        
                        var starCell = $(this).children("a.starEmpty,a.starFull"); 
                        if (starCell.length>0)
                            {insertedRow.children(".dppStar").get(0).appendChild(starCell.get(0));}
                         
       $(this).remove();
    }
    );
                     
    //add alternating row color effect.
    DiscussPlus_alternateRowColors(newTblBody);
         
    outerDiv.show(); 
    
    function getTdOpenTag(cls,topicID,align) {
        return "<td class='dppCell " + cls + " ' name='topic" + topicID + "'>";        
    }
}

function DiscussPlus_alternateRowColors(tableElement) {
    
    tableElement.children("tr:odd").addClass("r-a").removeClass("row");
    tableElement.children("tr:even").addClass("row").removeClass("r-a")
}

function DiscussPlus_setDefaultSort() {
    var sorting = [[6, -1]]; //last mod date, descending.
    if (DiscussPlus_AnyTopicsInGrid()) {
        $("#dppTblTopics").trigger("sorton", [sorting]);
    }
}

function DiscussPlus_AnyTopicsInGrid() {
    return $("#dppTblTopics tr").length>1;
}
function DiscussPlus_addTableSorter() {
    $("#dppTblTopics").tablesorter(
            {
                headers: { 
                            0: { sorter: false},
                            1: { sorter: false} 
                        }
            }
        ).bind("sortEnd",function() {DiscussPlus_alternateRowColors($("#dppTblTopicsBody")); });
}

function DiscussPlus_LoadAdditionalDetails() {
    var topicData =  dpp_pluginPrefix + "topicIDList=" +  DiscussPlus_getSerializedTopicList();
    var postbacklink = dpp_callbackURL + "&" + dpp_pluginPrefix + "requestType=TopicInfoJSON_ALL&" + dpp_pluginPrefix + "&" + dpp_pluginPrefix + "jsoncallback=?"
    $.post(postbacklink,topicData, function (data) {
                                                     var topics= eval(data);
                                                     for(var topic in topics) {
                                                        if (topics.hasOwnProperty(topic)) {
                                                            var updateRow = $('#dppTopicRow' + topics[topic].topicId);
                                                            updateRow.children(".dppBugIcon").html(topics[topic].htmlCaseIcon);
                                                            updateRow.children(".dppViewCount").html(topics[topic].viewCount);
                                                            updateRow.children(".dppLastMod").html(topics[topic].lastModAsLocalTimeString);                                                                                                                        
                                                        }
                                                     }
                                                  DiscussPlus_AJAXLoadComplete(); 
                                   }
      );                                                                          
}

function DiscussPlus_AJAXLoadComplete() {
        DiscussPlus_addTableSorter();
        DiscussPlus_setDefaultSort();
}

function DiscussPlus_fixCommentColumnText(commentText) {
    //get rid of everything except numeric part

    var regexNumericPart = /(\d+)/;
    var matchParts = commentText.match(regexNumericPart);

    if (matchParts != null) {
        return matchParts[1]; 
    }
    else {return '0';}
}

/** These methods are used to detect which FogBugz page is open **/
function DiscussPlus_onTopicListPage() {
    return (
            ($("#idThisDiscussionGroup").length!=0) && //topic list header
            (!DiscussPlus_onTopicItemPage()) &&
            (!DiscussPlus_onTopicItemEditPage()) 
           );
}

function DiscussPlus_onTopicItemPage() {
    return ($("#discussplusItemViewMarker").length != 0);
}

function DiscussPlus_onTopicItemEditPage() {
    return ($("#discussplusEditMarker").length != 0);
}

/** Get postback URL for AJAX calls **/
function DiscussPlus_getPostBackURL() {
    return $("#dpp_callbackurl").val();
}

function DiscussPlus_getPluginPrefixFromCallBackUrl(url) {
    var pid = DiscussPlus_getPluginIDFromCallBackUrl(url)
    return "P" + pid + "_";
}

function DiscussPlus_getPluginIDFromCallBackUrl(url) {
    //url will be in format: default.asp?pg=pgPluginRaw&ixPlugin=14
    var regExPlugInId = /ixPlugin[=](\d+)/i;
    return url.toString().match(regExPlugInId)[1];
}

function DiscussPlus_getTopicIdFromURL(url) {
    //link format http://aus-nb-63q4rc1.iediscovery.com/FogBugz/default.asp?discussiongroupname.1.2.3
    // Where the last three digits are GroupID.TopicID.CommentCount

    var regExTopicID = /\d+\.(\d+)\.\d+$/;
    return url.toString().match(regExTopicID)[1];
}

function DiscussPlus_replaceNull(str,replace) {
    if (str == null) {
        return replace;
    }
    else {
        return str;
    }
}

function DiscussPlus_getSerializedTopicList() {
    var topicIdArr = new Array();
    var topicRows = $("#dppTblTopicsBody").children();
    var topicCount = topicRows.length;
    
    topicRows.each( function() 
                    {
                        topicIdArr[topicIdArr.length] = $(this).attr('name');
                    }
                  );
    
    return topicIdArr.toString();
}

function DiscussPlus_outerHTML(element) {
   return  $('<div>').append(element.clone()).remove().html();
}

function DiscussPlus__AddViewToggleMenu() {
    var currentIcon; var flatIcon = 'flat.gif';var gridIcon = 'calendar.png';
    var currentLabel; var flatLabel = 'Flat view'; var gridlabel = 'Grid view';
    var altIcon; var altLabel;
    var title = 'Discussion Topics';
    
    var showGrid = DiscussPlus_ShowGridView();
    if (showGrid) {
        currentIcon = gridIcon; currentLabel = gridlabel;
        altIcon = flatIcon; altLabel = flatLabel;
    }
    else {
        currentIcon = flatIcon; currentLabel = flatLabel;
        altIcon = gridIcon; altLabel = gridlabel;
    }

    var viewMenu = $("<div></div>").attr("id", "dp_viewToggleToolbar").addClass("listToolbar")
                   .append($("<span></span>").attr("id", "dp_viewToggleMenuBar").addClass("dp_ViewToggleLink")
                                             .append($("<img>").attr("src", "images/" + currentIcon).attr("id", "dp_viewToggleBarImg").addClass("dp_ViewToggleImage"))
                                             .append($("<span>" + currentLabel + "</span>").attr("id","dp_viewToggleBar").addClass("dp_ViewToggleLabel"))
                                             .append($("<img>").addClass("arrow").attr("src", "images/downArrow.gif"))                          
                                             .click(function() {
                                                             var top = $("#dp_viewToggleToolbar").offset().top + $("#dp_viewToggleToolbar").height();
                                                             var left = $("#dp_viewToggleBarImg").offset().left;
                                                             var width = $("#dp_viewToggleMenuBar").width();
                                                             $("#dp_viewToggleMenu").css({ "left": left + "px", "top": top + "px", "width": width + "px" });                 
                                                             $("#dp_viewToggleMenu").slideToggle("fast");
                                                             }
                                                  )                           
                          );


    var viewMenuItems = $("<div></div>")
                                        .attr("id", "dp_viewToggleMenu")
                                        .append($("<div></div>")
                                                                .addClass("dp_ViewToggleMenuItem")
                                                                .append($("<a></a>").attr("href", "#")                                                            
                                                                            .css({ "text-decoration": "none" })
                                                                            .append($("<img>").attr("src", "images/" + altIcon).addClass("dp_ViewToggleImage"))
                                                                            .append($("<span>" + altLabel + "</span>").addClass("highlight").addClass("dp_ViewToggleLabel"))
                                                                            .click(function() { DiscussPlus_setView(showGrid); return false; })
                                                                       )
                                                );                                                                                   
                         
    viewMenu.append(viewMenuItems);
    $("#containerDiscussTopics").before($("<h2></h2>")
                                .attr("id","dp_PageTitle")
                                .prepend(title)
                    );

    $("h1.discuss").prepend(viewMenu);
    $(".dp_ViewToggleMenuItem").hover(
                                       function() { $(this).addClass("dp_ViewToggleMenuItem_Hover"); },
                                       function() { $(this).removeClass("dp_ViewToggleMenuItem_Hover"); }
                                     );
        
}

function DiscussPlus_setView(viewAsList) {

    if (DiscussPlus_ShowGridView() ? viewAsList : !viewAsList) {
        // if current view != requeted view, switch
        $.cookie("dpShowListView", viewAsList.toString(), { expires: 30 });
        document.location.replace(document.location);
    }
    else {
        $("#dp_viewToggleMenu").slideUp("fast");
    }
}

function DiscussPlus_ShowGridView() {
    return ($.cookie("dpShowListView") != true.toString());
}